/*
 * stmt.h
 *
 * Ullrich von Bassewitz, 19.06.1998
 */



#ifndef STMT_H
#define STMT_H



/*****************************************************************************/
/*	    			     Code		     		     */
/*****************************************************************************/



int compound ();
/* Compound statement.	Allow any number of statements, inside braces. */



/* End of stmt.h */

#endif



