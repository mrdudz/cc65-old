/*
 * preproc.h
 *
 * Ullrich von Bassewitz, 07.06.1998
 */



#ifndef PREPROC_H
#define PREPROC_H



/*****************************************************************************/
/*	       			     data				     */
/*****************************************************************************/



/* Token table entry */
struct tok_elt {
    char *toknam;
    int toknbr;
};

/* Escape codes used by the preprocessor. The codes will be detected and
 * handled by the scanner. The purpose is to pass things up to the scanner
 * that should be handled by the preprocessor, but may not handled there,
 * because handling would happen outside the parser flow.
 */
#define	PP_ESC		255
#define PP_PRAGMA	0



/*****************************************************************************/
/*	       			     code				     */
/*****************************************************************************/



void AddNumericMacro (const char* Name, long Val);
/* Add a macro for a numeric constant - external call.
 * Must not be called while parsing!
 */

void AddTextMacro (const char* Name, const char* Val);
/* Add a macro for a textual constant - external call.
 * Must not be called while parsing!
 */

void PrintMacroStats (FILE* F);
/* Print macro statistics to the given text file. */

int searchtok (const char *sym, const struct tok_elt* toks);
/* Search a token in a table */

void preprocess (void);
/* Preprocess a line */



/* End of preproc.h */
#endif





