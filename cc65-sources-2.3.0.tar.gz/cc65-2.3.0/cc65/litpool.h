/*
 * litpool.h
 *
 * Ullrich von Bassewitz, 06.08.1998
 */



#ifndef LITPOOL_H
#define LITPOOL_H



/*****************************************************************************/
/*				     data				     */
/*****************************************************************************/



#define LITPOOL_SIZE   	4096			/* Max strings per function */

extern unsigned char litpool [LITPOOL_SIZE];	/* The literal pool */
extern unsigned litptr;				/* Current pool offset */
extern unsigned litlabel;			/* Pool asm label */
extern unsigned litspace;			/* Space used (stats only) */



/*****************************************************************************/
/*		 		     code				     */
/*****************************************************************************/



void littrans (unsigned offs);
/* Translate the literals starting from the given offset into the target
 * charset.
 */

void dumplits (void);
/* Dump the literal pool */



/* End of litpool.h */
#endif





