/*
 * stmt.h
 *
 * Ullrich von Bassewitz, 19.06.1998
 */



#ifndef STMT_H
#define STMT_H



/*****************************************************************************/
/*	  	  	       	     data		     		     */
/*****************************************************************************/



#define MAX_LEVELS	256		/* Maximum nesting level */
extern unsigned CurrentLevel;		/* Current nesting level */
extern int LevelSP [MAX_LEVELS];	/* Stack offsets for the levels */



/*****************************************************************************/
/*	    			     code		     		     */
/*****************************************************************************/



int compound ();
/* Compound statement.	Allow any number of statements, inside braces. */



/* End of stmt.h */

#endif



