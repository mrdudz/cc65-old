/*
 * util.h
 *
 * Ullrich von Bassewitz, 18.06.1998
 */



#ifndef UTIL_H
#define UTIL_H



#include "datatype.h"



/*****************************************************************************/
/*		   		     data		     		     */
/*****************************************************************************/



#define DECODE_SIZE	3	/* Need 3 bytes for 16 bits */



/*****************************************************************************/
/*				     code		     		     */
/*****************************************************************************/



unsigned getlabel (void);
/* Get an unused label. Will never return zero. */

int IsBlank (char c);
/* Return true if c is a space or a tab */

void encode (type* p, unsigned w);
/* Encode p[0] and p[1] so that neither p[0] nore p[1] is zero */

unsigned decode (const type* p);
/* Decode */

unsigned HashStr (const char *s);
/* Produce a hash value from string s */

int powerof2 (unsigned long val);
/* Return the exponent if val is a power of two. Return -1 if val is not a
 * power of two.
 */

void DumpType (type* tptr);
/* Dump a type string to stdout (for debugging) */



/* End of util.h */

#endif



