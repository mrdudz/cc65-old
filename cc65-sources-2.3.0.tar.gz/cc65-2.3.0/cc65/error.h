/*
 * error.h
 *
 * Ullrich von Bassewitz, 07.06.1998
 */



#ifndef ERROR_H
#define ERROR_H



/*****************************************************************************/
/*	  			     data		     		     */
/*****************************************************************************/



/* Warning numbers */
enum Warnings {
    WARN_NONE,		 	   	/* No warning */
    WARN_UNREACHABLE_CODE,
    WARN_COND_NEVER_TRUE,
    WARN_COND_ALWAYS_TRUE,
    WARN_PTR_TO_INT_CONV,
    WARN_INT_TO_PTR_CONV,
    WARN_FUNC_WITHOUT_PROTO,
    WARN_UNKNOWN_PRAGMA,
    WARN_NO_CASE_LABELS,
    WARN_FUNC_MUST_BE_EXTERN,
    WARN_UNUSED_PARM,
    WARN_UNUSED_ITEM,
    WARN_OUTPUT_FLUSH,
    WARN_CONSTANT_IS_LONG,
    WARN_COUNT			   	/* Warning count */
};

/* Error numbers */
enum Errors {
    ERR_NONE,	       	       		/* No error */
    ERR_INVALID_CHAR,
    ERR_UNEXPECTED_NEWLINE,
    ERR_EOF_IN_COMMENT,
    ERR_SYNTAX,
    ERR_QUOTE_EXPECTED,
    ERR_COLON_EXPECTED,
    ERR_SEMICOLON_EXPECTED,
    ERR_LPAREN_EXPECTED,
    ERR_RPAREN_EXPECTED,
    ERR_LBRACK_EXPECTED,
    ERR_RBRACK_EXPECTED,
    ERR_LCURLY_EXPECTED,
    ERR_RCURLY_EXPECTED,
    ERR_IDENT_EXPECTED,
    ERR_TYPE_EXPECTED,
    ERR_INCOMPATIBLE_TYPES,
    ERR_INCOMPATIBLE_POINTERS,
    ERR_TOO_MANY_FUNC_ARGS,
    ERR_TOO_FEW_FUNC_ARGS,
    ERR_MACRO_ARGCOUNT,
    ERR_VAR_IDENT_EXPECTED,
    ERR_INT_EXPR_EXPECTED,
    ERR_CONST_EXPR_EXPECTED,
    ERR_NO_ACTIVE_LOOP,
    ERR_INCLUDE_LTERM_EXPECTED,
    ERR_INCLUDE_RTERM_EXPECTED,
    ERR_INCLUDE_NOT_FOUND,
    ERR_INCLUDE_OPEN_FAILURE,
    ERR_INVALID_USER_ERROR,
    ERR_USER_ERROR,
    ERR_UNEXPECTED_CPP_ENDIF,
    ERR_UNEXPECTED_CPP_ELSE,
    ERR_CPP_ENDIF_EXPECTED,
    ERR_CPP_DIRECTIVE_EXPECTED,
    ERR_FUNC_REDEFINITION,
    ERR_MULTIPLE_DEFINITION,
    ERR_INVALID_TYPE,
    ERR_STRLIT_EXPECTED,
    ERR_WHILE_EXPECTED,
    ERR_MUST_RETURN_VALUE,
    ERR_CANNOT_RETURN_VALUE,
    ERR_UNEXPECTED_CONTINUE,
    ERR_UNDEFINED_SYMBOL,
    ERR_UNDEFINED_LABEL,
    ERR_INCLUDE_NESTING,
    ERR_TOO_MANY_LOCALS,
    ERR_TOO_MANY_INITIALIZERS,
    ERR_CANNOT_SUBSCRIPT,
    ERR_OP_NOT_ALLOWED,
    ERR_STRUCT_EXPECTED,
    ERR_STRUCT_FIELD_MISMATCH,
    ERR_STRUCT_PTR_EXPECTED,
    ERR_LVALUE_EXPECTED,
    ERR_EXPR_EXPECTED,
    ERR_ILLEGAL_TYPE,
    ERR_ILLEGAL_FUNC_CALL,
    ERR_ILLEGAL_INDIRECT,
    ERR_ILLEGAL_ADDRESS,
    ERR_ILLEGAL_MACRO_CALL,
    ERR_ILLEGAL_HEX_DIGIT,
    ERR_ILLEGAL_CHARCONST,
    ERR_ILLEGAL_MODIFIER,
    ERR_DIV_BY_ZERO,
    ERR_MOD_BY_ZERO,
    ERR_RANGE,
    ERR_SYMBOL_KIND,
    ERR_LEVEL_NESTING,
    ERR_MISSING_PARAM_NAME,
    ERR_OLD_STYLE_PROTO,
    ERR_PARAM_DECL,
    ERR_CANNOT_TAKE_ADDR_OF_REG,
    ERR_COUNT 	     	    	   	/* Error count */
};

/* Fatal errors */
enum Fatals {
    FAT_NONE,
    FAT_TOO_MANY_ERRORS,
    FAT_CANNOT_OPEN_OUTPUT,
    FAT_CANNOT_WRITE_OUTPUT,
    FAT_CANNOT_OPEN_INPUT,
    FAT_OUT_OF_MEMORY,
    FAT_STACK_OVERFLOW,
    FAT_STACK_EMPTY,
    FAT_OUT_OF_STRSPACE,
    FAT_TOO_MANY_CASE_LABELS,
    FAT_COUNT				/* Fatal error count */
};



extern int errcnt;    	 	/* errors in compilation */



/*****************************************************************************/
/* 	       	      	 	     code				     */
/*****************************************************************************/



void Warning (unsigned char WarnNum, ...);
/* Print warning message. */

void Error (unsigned char ErrNum, ...);
/* Print an error message */

void Fatal (unsigned char FatNum, ...);
/* Print a message about a fatal error and die */

void Internal (char* Format, ...);
/* Print a message about an internal compiler error and die. */

void ErrorReport (void);
/* Report errors (called at end of compile) */



/* End of error.h */
#endif





