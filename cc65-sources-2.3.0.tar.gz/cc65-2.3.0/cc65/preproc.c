
/* C pre-processor functions */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>

#include "global.h"
#include "mem.h"
#include "util.h"
#include "error.h"
#include "io.h"
#include "ident.h"
#include "include.h"
#include "scanner.h"
#include "expr.h"
#include "codegen.h"
#include "preproc.h"



#define ch()	(*lptr)



static int pp0 (char *curlin);
static int pp1 (char *from, char *to);
static int pp2 (char *from, char *to, char *(*pfind) (), void (*prepl) ());
static void xlateline (void);



/*****************************************************************************/
/*		    		     data				     */
/*****************************************************************************/



/* Management data for #if */
#define N_IFDEF		16
static int i_ifdef = -1;
static char s_ifdef[N_IFDEF];

/* Macro hash table */
#define MACRO_TAB_SIZE	211
static char* MacroTab [MACRO_TAB_SIZE];

/* Macro argument table */
#define MACARG_TAB_SIZE	256
static char* MacroArgs [MACARG_TAB_SIZE];

/* */
static unsigned char MacroLTab [256];

/* Buffer for macro expansion */
static char mlinebuf [LINESIZE];
static char* mline = mlinebuf;

/* Macro table search variables */
static int tbllen;
static char* tblptr;
static char* mptr;

/* Flag: Don't expand macros in this line */
static int NoMacExpand = 0;



/*****************************************************************************/
/* 		    		     code				     */
/*****************************************************************************/



static int quote_p (char c)
{
    return (c == '"' || c == '\'');
}



static int keepch (char c)
/* Put character c into translation buffer. */
{
    return (*mptr++ = c);
}



static void keepstr (char *str)
/* Put string str into translation buffer. */
{
    while (*str)
	*mptr++ = *str++;
}



static void comment (void)
/* Remove comment from line. */
{
    gch ();
    gch ();
    while ((ch () != '*') || (nch () != '/')) {
	if (ch () == '\0') {
	    if (readline () == 0) {
		Error (ERR_EOF_IN_COMMENT);
	    	return;
	    }
	} else {
	    ++lptr;
	}
    }
    gch ();
    gch ();
}



static void skipblank (void)
/* Skip blanks and tabs in the input stream. */
{
    while (IsBlank (ch ())) {
	++lptr;
    }
}



static void skipquote (int qchar)
/* Copy single or double quoted string from lptr to mptr. */
{
    char c;

    keepch (gch ());
    while ((c = ch ()) != qchar && c != '\0') {
	/* keep escaped char */
	if (c == '\\')
	    keepch (gch ());
	keepch (cgch ());
    }
    if (c) {
	keepch (gch ());
    }
}



static int macname (char *sname)
/* Get macro symbol name.  If error, print message and kill line. */
{
    if (issym (sname) == 0) {
	Error (ERR_IDENT_EXPECTED);
	kill ();
	return (0);
    } else {
	return (1);
    }
}



static char* findarg (char *sname)
/* Look up sname in formal argument table, MacroArgs.  There are fcnt
 * symbols in the table.
 */
{
    int i;
    char *p;

    for (i = 0, p = tblptr; i < tbllen; ++i) {
	if (!strcmp (sname, p)) {
	    return (MacroArgs [i]);
	}
	p += strlen (p) + 1;
    }
    return 0;
}



static int domcall (char *macptr)
/* Process a macro call. */
{
    int acnt;
    int c;
    int k;
    int nparen;
    char *p;
    char *q;
    char *saveptr;
    char *sv;

    skipblank ();
    if (ch () != '(') {
	Error (ERR_ILLEGAL_MACRO_CALL);
	return 0;
    }
    gch ();
    sv = p = q = xmalloc (256);	       	/* OOPS! ### */
    acnt = 0;
    nparen = 0;
    while (1) {
	c = ch ();
   	if (c == '(') {
	    *q++ = gch ();
    	    ++nparen;
	} else if (quote_p (c)) {
	    saveptr = mptr;
	    mptr = q;
	    skipquote (c);
	    q = mptr;
	    mptr = saveptr;
	} else if (c == ',' || c == ')') {
	    if (nparen == 0) {
	    	gch ();
	    	*q++ = '\0';
	    	MacroArgs [acnt++] = p;
	    	p = q;
	    	if (c == ')') {
	    	    break;
	    	}
	    } else {
	    	*q++ = gch ();
	    	if (c == ')') {
	    	    --nparen;
	    	}
	    }
	} else if (IsBlank (c)) {
	    *q++ = ' ';
	    skipblank ();
	} else if (c == '\0') {
	    if (readline () == 0) {
	    	return 0;
	    }
	} else {
	    *q++ = gch ();
	}
    }

    /* compare formal argument count with actual */
    if (acnt != (tbllen = *macptr++ & 0xFF)) {
       	if (tbllen != 0 || acnt != 1 || *MacroArgs [0]) {
	    Error (ERR_MACRO_ARGCOUNT);
	    while (acnt < tbllen) {
	    	MacroArgs [acnt++] = "";
	    }
	}
    }

    /* move pointer past formal argument list */
    tblptr = macptr;
    for (k = 0; k < tbllen; ++k) {
	while (*macptr++) ;
    }

    saveptr = lptr;
    pp2 (macptr, mptr, findarg, keepstr);
    lptr = saveptr;
    return 1;
}



static int pp1 (char* from, char* to)
/* Preprocessor pass 1.  Remove whitespace and comments. */
{
    int c;
    int done;
    char sname [NAMESIZE];

    lptr = from;
    mptr = to;
    done = 1;
    while ( (c = ch ()) ) {
	if (IsBlank (c)) {
	    keepch (' ');
	    skipblank ();
	} else if (NoMacExpand == 0 && IsIdent (c)) {
	    symname (sname);
	    if (MacroLTab [(unsigned)(unsigned char)sname[0]]) {
	    	done = 0;
	    }
	    keepstr (sname);
	} else if (quote_p (c)) {
	    skipquote (c);
	} else if (c == '/' && nch () == '*') {
	    keepch (' ');
	    comment ();
	} else if (ANSI == 0 && c == '/' && nch () == '/') {
	    keepch (' ');
	    lptr += strlen (lptr);     		/* Skip until terminator */
	} else {
	    *mptr++ = *lptr++;
	}
    }
    keepch ('\0');
    NoMacExpand = 0;
    return done;
}



static int pp2 (char *from, char *to, char *(*pfind) (), void (*prepl) ())
/* Preprocessor pass 2.  Perform macro substitution. */
{
    int c;
    int no_chg;
    char *s;
    char sname[NAMESIZE];

    lptr = from;
    mptr = to;
    no_chg = 1;
    while ( (c = ch ()) ) {
	if (IsIdent (c)) {
	    symname (sname);
       	    if ( (s = (*pfind) (sname)) ) {
	    	(*prepl) (s);
	    	no_chg = 0;
	    } else {
	    	keepstr (sname);
	    }
     	} else if (c == '#' && IsIdent (nch ())) {
     	    ++lptr;
     	    symname (sname);
       	    if ( (s = (*pfind) (sname)) ) {
     	    	keepch ('\"');
     	    	(*prepl) (s);
     	    	keepch ('\"');
     	    	no_chg = 0;
     	    } else {
     	    	keepch ('#');
     	    	keepstr (sname);
     	    }
	} else if (quote_p (c)) {
	    skipquote (c);
	} else {
	    *mptr++ = *lptr++;
	}
    }
    return no_chg;
}



static void replmac (char *pdef)
/* Function copies definition (pointed to by pdef) of current macro
 * symbol to mline.
 */
{
    pdef += strlen (pdef) + 1;
    if (*pdef & 0x80) {
	if (domcall (pdef + 1) == 0) {
	    kill ();
   	}
    } else {
	keepstr (pdef);
    }
}



/* Look up sname in macro table. */
static char* findmac (char* sname)
{
    char *p;

    unsigned h = HashStr (sname) % MACRO_TAB_SIZE;
    for (p = MacroTab [h]; p != NULL; p = *((char **) p)) {
	if (strcmp (sname, p + sizeof (char *)) == 0) {
	    return (p + sizeof (char *));
	}
    }
    return 0;
}



static void doundef (void)
/* Process #undef directive */
{
    char *s;
    char sname[NAMESIZE];

    skipblank ();
    if (macname (sname) && (s = findmac (sname))) {
	*s = '\0';
    }
}



static int setmflag (int skip, int flag, int cond)
/* setmflag( skip, flag, cond ) */
{
    if (skip) {
	s_ifdef[++i_ifdef] = 3;
	return (1);
    } else {
	s_ifdef[++i_ifdef] = 6;
	return (flag ^ cond);
    }
}



static int doiff (int skip)
/* Process #if directive */
{
    struct expent lval;
    char* S;

    /* We're about to abuse the compiler expression parser to evaluate the
     * #if expression. Save the current tokens to come back here later.
     */
    int sv1 = curtok;
    int sv2 = nxttok;

    /* Remove the #if from the line and add two semicolons as sentinels */
    skipblank ();
    S = line;
    while ((*S++ = *lptr++) != '\0') ;
    strcat (line, ";;");
    lptr = line;

    /* Expand macros in this line */
    xlateline ();

    /* Prime the token pump (remove old tokens from the stream) */
    gettok ();
    gettok ();

    /* Call the expression parser */
    constexpr (&lval);

    /* Reset the old tokens */
    curtok = sv1;
    nxttok = sv2;

    /* Set the #if condition according to the expression result */
    return (setmflag (skip, 1, lval.e_const != 0));
}



static int doifdef (int skip, int flag)
/* Process #ifdef if flag == 1, or #ifndef if flag == 0. */
{
    char sname[NAMESIZE];

    skipblank ();
    if (macname (sname) == 0) {
	return (0);
    } else {
	return (setmflag (skip, flag, findmac (sname) != 0));
    }
}



static void addmac (void)
/* Add a macro to the macro table. */
{
    int h;
    char *p;
    char *pcnt;
    char *saveptr;
    char sname[NAMESIZE];
    char *sptr;

    skipblank ();
    if (!macname (sname)) {
	return;
    }

    /* Save macro name */
    h = HashStr (sname) % MACRO_TAB_SIZE;
    sptr = xmalloc (256);    		/* Huh?? ### */
    strcpy (sptr + sizeof (char*), sname);
    p = sptr + sizeof (char *) + strlen (sname) + 1;
    MacroLTab [(unsigned)(unsigned char)sname[0]] = 1;

    if (ch () == '(') {

       	/* save dummy arguments */
	*p++ = 0x80;
	*(pcnt = p++) = 0;
	gch ();
	while (1) {
	    skipblank ();
	    if (ch () == ')')
	    	break;
	    if (macname (sname) == 0) {
	    	return;
	    }
	    strcpy (p, sname);
	    ++*pcnt;
	    p += strlen (sname) + 1;
	    skipblank ();
	    if (ch () != ',')
	    	break;
	    gch ();
	}
	if (ch () != ')') {
       	    Error (ERR_RPAREN_EXPECTED);
	    kill ();
	    return;
   	}
	gch ();
    }

    /* Save macro value */
    *((char **) sptr) = MacroTab [h];
    MacroTab [h] = sptr;
    skipblank ();
    saveptr = mptr;
    if (pp0 (lptr)) {
	pp1 (lptr, p);
    } else {
	strcpy (p, lptr);
    }
    mptr = saveptr;
}



static void doinclude (void)
/* Open an include file. */
{
    char name [80];
    unsigned count;
    char term;
    char c;
    char *p;

    if (ifile >= MAXFILES) {
     	Error (ERR_INCLUDE_NESTING);
     	goto done;
    }
    mptr = mline;
    skipblank ();
    if (!strchr ("\"<", (term = cgch ()))) {
       	Error (ERR_INCLUDE_LTERM_EXPECTED);
     	goto done;
    }
    if (term == '<') {
     	term = '>';	  	/* get right terminator */
    }

    /* Get the name of the include file */
    count = 0;
    while ((c = *lptr) && (c != term) && count < sizeof (name)-1) {
	name [count++] = c;
	++lptr;
    }
    if (c != term) {
 	Error (ERR_INCLUDE_RTERM_EXPECTED);
	goto done;
    }
    name [count] = '\0';

    /* Now search for the name */
    p = FindInclude (name, (term == '\"')? INC_USER : INC_SYS);
    if (p == 0) {
	Error (ERR_INCLUDE_NOT_FOUND, name);
     	goto done;
    }

    /* Save the existing file info */
    filetab[ifile].f_ln = ln;
    filetab[ifile].f_name = fin;
    filetab[ifile].f_iocb = inp;
    ++ifile;

    /* Assign the name and output it */
    fin = p;
    if (Verbose) {
	printf ("including '%s'\n", fin);
    }

    /* Try to open the include file */
    if ((inp = fopen (fin, "r")) == 0) {
	/* oops! restore old file */
	Error (ERR_INCLUDE_OPEN_FAILURE, fin);
	xfree (fin);
	--ifile;
     	inp = filetab[ifile].f_iocb;
     	fin = filetab[ifile].f_name;
    } else {
     	ln = 0;
    }

done:
    /* clear rest of line so next read will come from new file (if open) */
    kill ();
}



static void doerror (void)
/* Print an error */
{
    skipblank ();
    if (ch () == '\0') {
 	Error (ERR_INVALID_USER_ERROR);
    } else {
        Error (ERR_USER_ERROR, lptr);
    }

    /* clear rest of line */
    kill ();
}



static void xlateline (void)
/* Translate one line. */
{
    int cnt;
    int done;
    char *p;

    done = pp1 (line, mline);
    cnt = 5;
    do {
	p = line;
	line = mline;
	mline = p;
	if (done)
	    break;
	done = pp2 (line, mline, findmac, replmac);
	keepch ('\0');
    } while (--cnt);
    lptr = line;
}



static int pp0 (char *curlin)
/* Convert tabs to blanks and determine whether further pre-processing
 * is necessary
 */
{
    int flag;

    flag = 0;
    while (*curlin) {
   	switch (*curlin) {
   	    case '\t':
   	    	*curlin = ' ';
   	    	break;
   	    case '\'':
   	    case '"':
       	    	++flag;
   	    	break;
   	    case '/':
   	    	if (curlin[1] == '*') {
   	    	    ++flag;
   	    	    ++curlin;
   	    	}
   	    	break;
	}
	++curlin;
    }
    return flag;
}



void AddNumericMacro (const char* Name, long Val)
/* Add a macro for a numeric constant - external call.
 * Must not be called while parsing!
 */
{
    lptr = line;
    sprintf (line, "%s %ld", Name, Val);
    addmac ();
    kill ();
}



void AddTextMacro (const char* Name, const char* Val)
/* Add a macro for a textual constant - external call.
 * Must not be called while parsing!
 */
{
    lptr = line;
    sprintf (line, "%s %s", Name, Val);
    addmac ();
    kill ();
}



void PrintMacroStats (FILE* F)
/* Print macro statistics to the given text file. */
{
    unsigned i;
    char* q;

    fprintf (F, "\n\nMacro Hash Table Summary\n");
    for (i = 0; i < MACRO_TAB_SIZE; ++i) {
	fprintf (F, "%3d : ", i);
	if (MacroTab [i]) {
	    for (q = MacroTab [i]; q != NULL; q = *((char **) q)) {
		fprintf (F, "%s ", q + sizeof (char *));
	    }
	    fprintf (F, "\n");
	} else {
	    fprintf (F, "empty\n");
	}
    }
}



/* C preprocessor. */

/* stuff used to bum the keyword dispatching stuff */
enum {
    D_DEFINE,
    D_ELSE,
    D_ENDIF,
    D_ERROR,
    D_IF,
    D_IFDEF,
    D_IFNDEF,
    D_INCLUDE,
    D_LINE,
    D_PRAGMA,
    D_UNDEF,
    D_ILLEGAL,
};

static struct tok_elt pre_toks[] = {
    {	"define",	D_DEFINE	},
    {	"else",		D_ELSE		},
    {	"endif",	D_ENDIF		},
    {	"error",	D_ERROR		},
    {	"if",		D_IF		},
    {	"ifdef",	D_IFDEF		},
    {	"ifndef",	D_IFNDEF	},
    {	"include", 	D_INCLUDE	},
    {   "line",		D_LINE		},
    {	"pragma",	D_PRAGMA	},
    {	"undef",	D_UNDEF		},
    {	0,		D_ILLEGAL	}
};



int searchtok (const char *sym, const struct tok_elt *toks)
/* Search a token in a table */
{
    while (toks->toknam && strcmp (toks->toknam, sym))
	++toks;
    return (toks->toknbr);
}



void preprocess (void)
/* Preprocess a line */
{
    int c;
    int Skip;
    char sname[NAMESIZE];

    /* Process compiler directives, skip empty lines */
    lptr = line;

    /* Skip white space at the beginning of the line */
    skipblank ();

    /* Check for stuff to skip */
    Skip = 0;
    while ((c = ch ()) == '\0' || c == '#' || Skip) {

  	/* Check for preprocessor lines lines */
       	if (c == '#') {
    	    ++lptr;
    	    skipblank ();
    	    if (ch () == '\0') {
    	   	/* ignore the empty preprocessor directive */
    	   	continue;
    	    }
    	    if (!issym (sname)) {
    	    	Error (ERR_CPP_DIRECTIVE_EXPECTED);
    	    	kill ();
    	    } else {
       	       	switch (searchtok (sname, pre_toks)) {

    	    	    case D_DEFINE:
    	    		if (!Skip) {
    	    		    addmac ();
    	    		}
    	    		break;

    		    case D_ELSE:
    			if (s_ifdef[i_ifdef] & 2) {
    			    if (s_ifdef[i_ifdef] & 4) {
    			     	Skip = !Skip;
    			    }
    		    	    s_ifdef[i_ifdef] ^= 2;
    			} else {
    			    Error (ERR_UNEXPECTED_CPP_ELSE);
    			}
    			break;

    		    case D_ENDIF:
    			if (i_ifdef >= 0) {
    		     	    Skip = s_ifdef[i_ifdef--] & 1;
    			} else {
    			    Error (ERR_UNEXPECTED_CPP_ENDIF);
    			}
    			break;

       	       	    case D_ERROR:
			if (!Skip) {
	    		    doerror ();
			}
    	   		break;

    		    case D_IF:
    	   		Skip = doiff (Skip);
    	   		break;

    	   	    case D_IFDEF:
    	   		Skip = doifdef (Skip, 1);
    	   		break;

    	   	    case D_IFNDEF:
    	   		Skip = doifdef (Skip, 0);
    	   		break;

    	    	    case D_INCLUDE:
    	    		if (!Skip) {
    	    		    doinclude ();
    	    		}
    	    		break;

		    case D_LINE:
			/* Not allowed in strict ANSI mode */
			if (ANSI) {
			    Error (ERR_CPP_DIRECTIVE_EXPECTED);
			    kill ();
			}
			break;

    		    case D_PRAGMA:
			if (!Skip) {
			    /* Don't expand macros in this line */
			    NoMacExpand = 1;
    			    /* #pragma is handled on the scanner level */
			    goto Done;
			}
    			break;

    	    	    case D_UNDEF:
    	    		if (!Skip) {
    	    		    doundef ();
    	    		}
    	    		break;

    		    default:
    			Error (ERR_CPP_DIRECTIVE_EXPECTED);
    			kill ();
    		}
	    }

    	}
    	if (readline () == 0) {
    	    if (i_ifdef >= 0) {
    		Error (ERR_CPP_ENDIF_EXPECTED);
    	    }
    	    return;
    	}
  	skipblank ();
    }

Done:
    xlateline ();
    if (Verbose > 1) {
    	printf ("line: %s\n", line);
    }
}

