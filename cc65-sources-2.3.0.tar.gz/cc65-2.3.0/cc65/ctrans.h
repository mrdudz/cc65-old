/*
 * ctrans.h
 *
 * Ullrich von Bassewitz, 19.06.1998
 */



#ifndef CTRANS_H
#define CTRANS_H



/*****************************************************************************/
/*	      			     code		     		     */
/*****************************************************************************/



int ctrans (unsigned char c);
/* Translate a character from source charset into target charset */



/* End of ctrans.h */

#endif



