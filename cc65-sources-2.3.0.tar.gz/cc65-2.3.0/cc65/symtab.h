/*
 * symtab.h
 *
 * Ullrich von Bassewitz, 19.06.1998
 */



#ifndef SYMTAB_H
#define SYMTAB_H



#include <stdio.h>

#include "datatype.h"



/*****************************************************************************/
/*				     data				     */
/*****************************************************************************/



/* Storage classes */
#define SC_STACK       	0x0001
#define SC_STORAGE     	0x0002
#define SC_DEFINED     	0x0004	/* Symbol is defined */
#define SC_EXTERN      	0x0008
#define SC_STATIC	0x0010
#define SC_REGISTER    	0x0020	/* Register variable, is in static storage */
#define SC_ENUM	       	0x0040
#define SC_REF 	       	0x0080  /* Symbol is referenced */
#define SC_DEFAULT     	0x0100
#define SC_PARAM	0x0200	/* This is a function parameter */
#define SC_LABEL       	0x0400	/* A goto label */
#define SC_TYPE	       	0x1000	/* This is a type, struct, typedef, etc. */
#define SC_STRUCT      	0x1001
#define SC_SFLD	       	0x1001
#define SC_STAG	       	0x1002
#define SC_TYPEDEF     	0x1003
#define SC_ZEROPAGE	0x8000

/* Symbol table entry */
struct hashent {
    struct hashent*  	h_ptr;		/* Link for same hash value */
    unsigned 	     	h_glb;       	/* Flags SC_XXX for local symbol */
    unsigned 	     	h_loc;		/* Flags SC_XXX for global symbol */
    type*      	     	h_gtptr;     	/* Global variable type array */
    type*	     	h_ltptr;     	/* Local variable type array */
    struct hashent*  	h_link;		/* Linked queue of global symbols */
    int 	     	h_gdata;       	/* Name for global data */
    int 	     	h_ldata;       	/* Stack offset for local data */
    int		     	h_lattr;	/* Local attribute data */
    char 	     	h_name[1];	/* Name of symbol, dynamic length */
};

/* Local variable table and number of locals */
extern struct hashent* lvtab [128];
extern int lovptr;



/*****************************************************************************/
/*				     code				     */
/*****************************************************************************/



struct hashent* FindStructField (type* TypeArray, const char* Name);
/* Find a struct field in the fields list */

void addstag (struct hashent *psym, int sz);
/* Define a struct/union tag to the symbol table. */

struct hashent* addsym (const char* sym);
/* Add a symbol to the symbol table. */

void addglb (struct hashent* psym, type* tarray, int sc);
/* Add a global symbol to the symbol table */

void addloc (struct hashent* psym, type* tarray, int sc, int offs);
/* Add a local symbol. */

void DropLocals (int Check);
/* Drop local variables, check for unused params if requested. */

int EqualTypes (type* t1, type* t2);
/* Recursively compare two types. Return 1 if the types match, return 0
 * otherwise.
 */

void MakeZPSym (const char* Name);
/* Mark the given symbol as zero page symbol */

size_t SizeOf (const type* tarray);
/* Compute size of object represented by type array. */

size_t PSizeOf (const type* tptr);
/* Compute size of pointer object. */

unsigned TypeOf (const type* tptr);
/* Get the code generator base type of the object */

type* Indirect (type* tptr);
/* Do one indirection for the given type, that is, return the type where the
 * given type points to.
 */

int IsVoid (const type* tptr);
/* Return true if this is a void type */

int IsPtr (const type* tptr);
/* Return true if this is a pointer type */

int IsChar (const type* tptr);
/* Return true if this is a character type */

int IsInt (const type* tptr);
/* Return true if this is an integer type */

int IsLong (const type* tptr);
/* Return true if this is a long type (signed or unsigned) */

int IsUnsigned (const type* tptr);
/* Return true if this is an unsigned type */

int IsStruct (const type* tptr);
/* Return true if this is a struct type */

int IsFunc (const type* tptr);
/* Return true if this is a function type */

int IsFuncPtr (const type* tptr);
/* Return true if this is a function pointer */

int IsArray (const type* tptr);
/* Return true if this is an array type */

int IsCompatPtr (const type* rhs, const type* lhs);
/* rhs and lhs are two pointers (or arrays). Check if the data types are
 * compatible.
 */

void PrintSymbolTable (FILE* F);
/* Write the symbol table to the given file */

void dumpglbs (void);
/* Dump global symbol table, for debugging. */

void dumploc (struct hashent* pfunc);
/* Dump local symbol table, for debugging. */

void dumpnams (void);
/* dump names of globals */

void dumpstruct (void);
/* Dump structs/unions. */



/* End of symtab.h */

#endif






