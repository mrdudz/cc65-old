/*
 * datatype.h
 *
 * Ullrich von Bassewitz, 02.10.1998
 */



#ifndef DATATYPE_H
#define DATATYPE_H



/*****************************************************************************/
/*     	      	    	       	     Data   				     */
/*****************************************************************************/



/* Data types */
#define	T_END  	       	0x0000
#define T_CHAR 	       	0x0011
#define T_INT  	       	0x0012
#define	T_SHORT	       	0x0013
#define T_LONG 	       	0x0014
#define T_ENUM 	       	0x0015
#define T_UCHAR	       	0x0019
#define T_UINT 	       	0x001A
#define T_USHORT       	0x001B
#define T_ULONG	       	0x001C

#define T_FLOAT	       	0x0025
#define T_DOUBLE       	0x0026

#define T_TYPEDEF      	0x0001		/* Somewhat special - def'd type */
#define T_EMPTY	       	0x0002		/* Empty parameter list */
#define T_ELLIPSIS     	0x0003		/* ... */
#define T_VOID 	       	0x0004		/* void parameter list */
#define T_FUNC 	       	0x0005		/* Function */
#define T_FUNCN	       	0x0006		/* Function without arg count passing */
#define T_FUNCF	       	0x0007		/* Fastcall function */

#define T_UNSIGNED     	0x0008		/* Class */
#define T_INTEGER      	0x0010		/* Class */
#define T_REAL 	       	0x0020		/* Class */
#define T_POINTER      	0x0040		/* Class */
#define T_PTR  	       	0x0049
#define T_ARRAY	       	0x004A
#define T_STRUCT       	0x0080
#define T_UNION	       	0x0081
#define T_SMASK	       	0x003F



/* Type entry */
typedef unsigned short type;

/* Maximum length of a type string */
#define MAXTYPELEN   	30

/* Predefined type strings */
extern type type_int [];
extern type type_uint [];
extern type type_long [];
extern type type_ulong [];
extern type type_empty [];
extern type type_void [];
extern type type_ellipsis [];
extern type type_ifunc [];
extern type type_carray [];
extern type type_pchar [];



/*****************************************************************************/
/*     	      	      	       	     Code				     */
/*****************************************************************************/



unsigned TypeLen (const type* T);
/* Return the length of the type string */

int TypeCmp (const type* T1, const type* T2);
/* Compare two type strings */

type* TypeCpy (type* Dest, const type* Src);
/* Copy a type string */

type* TypeCat (type* Dest, const type* Src);
/* Append Src */

type* TypeDup (const type* T);
/* Create a copy of the given type on the heap */

type* TypeAlloc (unsigned Len);
/* Allocate memory for a type string of length Len. Len *must* include the
 * trailing T_END.
 */

void TypeFree (type* T);
/* Free a type string */



/* End of datatype.h */

#endif



