/*
 * pragma.c
 *
 * Ullrich von Bassewitz, 11.08.1998
 */



#include <stdlib.h>
#include <ctype.h>

#include "global.h"
#include "error.h"
#include "io.h"
#include "litpool.h"
#include "symtab.h"
#include "preproc.h"
#include "scanner.h"
#include "codegen.h"
#include "expr.h"
#include "pragma.h"



/*****************************************************************************/
/*		     		     data				     */
/*****************************************************************************/



/* Tokens for the #pragmas */
enum {
    PR_BSSSEG,
    PR_CODESEG,
    PR_DATASEG,
    PR_REGVARADDR,
    PR_RODATASEG,
    PR_ZPSYM,
    PR_ILLEGAL
};



/*****************************************************************************/
/*    	      	     	   	     code  				     */
/*****************************************************************************/



static void StringPragma (void (*Func) (const char*))
/* Handle a pragma that expects a string parameter */
{
    if (curtok != SCONST) {
	Error (ERR_STRLIT_EXPECTED);
    } else {
     	/* Get the string */
     	const char* Name = litpool + curval;

       	/* Call the given function with the string argument */
	Func (Name);

     	/* Reset the string pointer, removing the string from the pool */
     	litptr = curval;
    }

    /* Skip the string (or error) token */
    gettok ();
}



static void FlagPragma (unsigned char* Flag)
/* Handle a pragma that expects a boolean paramater */
{
    /* Read a constant expression */
    struct expent val;
    constexpr (&val);

    /* Store the value into the flag parameter */
    *Flag = val.e_const;
}



void DoPragma (void)
/* Handle pragmas */
{
    static const struct tok_elt Pragmas [] = {
      	{ 	"bssseg",       PR_BSSSEG	},
       	{       "codeseg",  	PR_CODESEG	},
      	{       "dataseg",  	PR_DATASEG	},
       	{       "regvaraddr",	PR_REGVARADDR	},
      	{       "rodataseg",	PR_RODATASEG	},
      	{       "zpsym",       	PR_ZPSYM  	},
      	{       0,     	   	PR_ILLEGAL	},
    };

    int Pragma;

    /* Skip the token itself */
    gettok ();

    /* Identifier must follow */
    if (curtok != IDENT) {
	Error (ERR_IDENT_EXPECTED);
	return;
    }

    /* Do we know this pragma? */
    Pragma = searchtok (((struct hashent*)curval)->h_name, Pragmas);
    if (Pragma == PR_ILLEGAL) { 	 
	/* According to the ANSI standard, we're not allowed to generate errors
	 * for unknown pragmas, however, we're allowed to warn - and we will
	 * do so. Otherwise one typo may give you hours of bug hunting...
	 */
    	Warning (WARN_UNKNOWN_PRAGMA);
     	return;
    }

    /* Skip the identifier and check for an open paren */
    gettok ();
    ConsumeLParen ();

    /* Switch for the different pragmas */
    switch (Pragma) {

	case PR_BSSSEG:
	    StringPragma (g_bssname);
	    break;

	case PR_CODESEG:
	    StringPragma (g_codename);
	    break;

	case PR_DATASEG:
	    StringPragma (g_dataname);
	    break;

	case PR_REGVARADDR:
	    FlagPragma (&AllowRegVarAddr);
	    break;

	case PR_RODATASEG:
	    StringPragma (g_rodataname);
	    break;

	case PR_ZPSYM:
	    StringPragma (MakeZPSym);
	    break;

	default:
       	    Internal ("Invalid pragma");
    }

    /* Closing paren needed */
    ConsumeRParen ();
}





