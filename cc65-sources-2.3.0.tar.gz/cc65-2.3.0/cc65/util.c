/*
 * util.c
 *
 * Ullrich von Bassewitz, 18.06.1998
 */



#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "util.h"



/*****************************************************************************/
/*		     		     data				     */
/*****************************************************************************/



/* Number of current label */
static unsigned nextlab = 0;



/*****************************************************************************/
/*		     	   	     code				     */
/*****************************************************************************/



unsigned getlabel (void)
/* Get an unused label. Will never return zero. */
{
    return ++nextlab;
}



int IsBlank (char c)
/* Return true if c is a space or a tab */
{
    return (c == ' ' || c == '\t');
}



void encode (type* p, unsigned w)
/* Encode p[0] and p[1] so that neither p[0] nore p[1] is zero */
{
    int i;
    for (i = 0; i < DECODE_SIZE; i++) {
	*p++ = w | 0x8000;
	w >>= 15;
    }
}



unsigned decode (const type* p)
/* Decode */
{
    int i;
    unsigned w;
    w = 0;
    for (i = DECODE_SIZE-1; i >= 0; i--) {
	w <<= 15;
	w |= (p [i] & 0x7FFF);
    }
    return w;
}



unsigned HashStr (const char* S)
/* Return a hash value for the given string */
{
    unsigned L, H;

    /* Do the hash */
    H = L = 0;
    while (*S) {
    	H = ((H << 3) ^ ((unsigned char) *S++)) + L++;
    }
    return H;
}



int powerof2 (unsigned long val)
/* Return the exponent if val is a power of two. Return -1 if val is not a
 * power of two.
 */
{
    int i;
    unsigned long mask;
    mask = 0x0001;

    for (i = 0; i < 32; ++i) {
	if (val == mask) {
	    return i;
	}
	mask <<= 1;
    }
    return -1;
}



void DumpType (type* tptr)
/* Dump a type string to stdout (for debugging) */
{
    while (*tptr) {
	printf ("%04X ", *tptr++);
    }
    printf ("\n");
}



