/*
 * global.c
 *
 * Ullrich von Bassewitz, 28.08.1998
 */



#include "global.h"



/*****************************************************************************/
/*     	      	    	       	     Data				     */
/*****************************************************************************/



unsigned char Target		= TGT_NONE; /* Target system */
unsigned char ANSI   	       	= 0;   	    /* Strict ANSI flag */
unsigned char WriteableStrings	= 0;   	    /* Literal strings are r/w */
unsigned char NoWarn		= 0;   	    /* Suppress warnings */
unsigned char Optimize		= 0;   	    /* Optimize flag */
unsigned char FavourSize	= 1;   	    /* Favour size over speed */
unsigned char InlineStdFuncs	= 0;   	    /* Inline some known functions */
unsigned char EnableRegVars	= 0;   	    /* Enable register variables */
unsigned char AllowRegVarAddr	= 0;	    /* Allow taking addresses of register vars */
unsigned char RegVarsToCallStack= 0;   	    /* Save reg variables on call stack */
unsigned char Verbose		= 0;   	    /* Verbose flag */
unsigned char IncSource		= 0; 	    /* Include source as comments */
unsigned char DebugInfo		= 0;	    /* Add debug info to the obj */
unsigned char Debug		= 0;	    /* Debug mode */




