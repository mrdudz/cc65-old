/*
 * declare.c
 *
 * Ullrich von Bassewitz, 20.06.1998
 */



#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>

#include "datatype.h"
#include "error.h"
#include "util.h"
#include "mem.h"
#include "symtab.h"
#include "scanner.h"
#include "expr.h"
#include "pragma.h"
#include "function.h"
#include "litpool.h"
#include "codegen.h"
#include "declare.h"



/*****************************************************************************/
/*			      internal functions			     */
/*****************************************************************************/



static void optional_modifiers (void)
/* Eat optional "const" or "volatile" tokens */
{
    while (curtok == CONST || curtok == VOLATILE) {
	/* Skip it */
 	gettok ();
    }
}



static void optionalint (void)
/* Eat an optional "int" token */
{
    if (curtok == INT) {
	/* Skip it */
 	gettok ();
    }
}



static void optionalsigned (void)
/* Eat an optional "signed" token */
{
    if (curtok == SIGNED) {
	/* Skip it */
 	gettok ();
    }
}



static void declenum (void)
/* Process body of enum. */
{
    int enumval;
    struct expent lval;
    struct hashent *psym;

    if (curtok != LCURLY) {
   	return;
    }
    gettok ();
    enumval = 0;
    while (curtok != RCURLY) {
   	if (curtok != IDENT) {
   	    Error (ERR_IDENT_EXPECTED);
   	    continue;
   	}
       	psym = (struct hashent *) curval;
   	gettok ();
   	if (curtok == ASGN) {
   	    gettok ();
   	    constexpr (&lval);
   	    enumval = lval.e_const;
   	}
   	addglb (psym, type_int, SC_ENUM);
   	psym->h_gdata = enumval++;
   	if (curtok != COMMA)
   	    break;
   	gettok ();
    }
    ConsumeRCurly ();
}



static unsigned declstruct (struct hashent *last, int strtype)
/* Process body of struct/union declaration. */
{
    struct hashent* psym;
    struct hashent* nsym;
    struct hashent* sadr;
    type tarray [MAXTYPELEN];
    unsigned offset;
    unsigned sz;
    int type;

    if (curtok != LCURLY) {
	return (0);
    }
    gettok ();
    sz = 0;
    while (curtok != RCURLY) {
	type = gettype (-1, &sadr);
	while (1) {
	    /* Get type and name of the struct field */
	    psym = declare (tarray, type, sadr, 0);

	    /* Allocate memory for a new hash entry */
       	    nsym = xmalloc (sizeof (struct hashent) + strlen (psym->h_name));
    	    memset (nsym, 0, sizeof (struct hashent));

	    /* Copy name, type, and other data for the entry */
	    strcpy (nsym->h_name, psym->h_name);
	    nsym->h_gtptr = TypeDup (tarray);
	    nsym->h_glb   = SC_SFLD;
	    nsym->h_gdata = (strtype == T_STRUCT)? sz : 0;

	    /* Link the new entry to the last one */
	    last->h_link = nsym;
	    last = nsym;

	    /* Calculate offset of next field/size of the union */
    	    offset = SizeOf (tarray);
	    if (strtype == T_STRUCT) {
	       	sz += offset;
	    } else {
	       	if (offset > sz) {
	       	    sz = offset;
	       	}
	    }

	    if (curtok != COMMA)
	       	break;
	    gettok ();
	}
	ConsumeSemi ();
    }

    /* Skip the closing brace and return the size */
    gettok ();
    return sz;
}



static struct hashent* decl (type** ptyp, int mode)
/* Recursively process declarators. Build a type array in reverse order. */
{
    struct expent lval;
    struct hashent *psym;
    type* Type;
    int sz;

    if (curtok == STAR) {
       	gettok ();
	/* Allow optional const or volatile modifiers */
	optional_modifiers ();
       	psym = decl (ptyp, mode);
       	*(*ptyp)++ = T_PTR;
       	return psym;
    } else if (curtok == LPAREN) {
       	gettok ();
       	psym = decl (ptyp, mode);
       	ConsumeRParen ();
    } else if (curtok == FASTCALL) {
      	gettok ();
	Type = *ptyp;
	psym = decl (ptyp, mode);
	if (!IsFunc (Type)) {
	    Error (ERR_ILLEGAL_MODIFIER);
	} else {
	    *Type = T_FUNCF;
	}
	return psym;
    } else {
	/* Things depend on mode now:
       	 *  - mode = 0 means, we *must* have a type and a variable identifer.
	 *  - mode = 1 means, we must have a type but no variable identifer
	 * 	     	      (if there is one, it's not read).
	 *  - mode = 2 means, we *may* have an identifier. If there is an
	 *                    identifier, it is read, but it is no error, if
	 *                    there is none.
	 */
	if (mode == 1) {
	    psym = 0;
	} else if (curtok == IDENT) {
	    psym = (struct hashent*) curval;
	    gettok ();
	} else {
    	    if (mode != 2) {
	    	Error (ERR_SYNTAX);
	    }
	    return 0;
	}
    }

    while (curtok == LBRACK || curtok == LPAREN) {
       	if (curtok == LPAREN) {
       	    type* signature;
	    int varparam;
       	    gettok ();
       	    ParseFuncArgs (&signature, &varparam);
       	    *(*ptyp)++ = varparam? T_FUNC : T_FUNCN;
       	    encode (*ptyp, (unsigned) signature);
       	    *ptyp += DECODE_SIZE;
       	} else {
       	    gettok ();
       	    sz = 0;
       	    if (curtok != RBRACK) {
       	   	constexpr (&lval);
       	   	sz = lval.e_const;
       	    }
       	    ConsumeRBrack ();
       	    *(*ptyp)++ = T_ARRAY;
       	    encode (*ptyp, sz);
       	    *ptyp += DECODE_SIZE;
       	}
    }
    return psym;
}



/*****************************************************************************/
/*	    		       	     code				     */
/*****************************************************************************/



int istypedef (struct hashent* psym)
/* Return true if psym is a typedef */
{
    return (psym->h_loc == SC_TYPEDEF || psym->h_glb == SC_TYPEDEF);
}



int gettypedef (struct hashent** psym, type* tarray)
/* Check if the following tokens are a typedef. If so, process it and return
 * true. If not, return false. The symbol and the type are returned as psym
 * and tarray.
 */
{
    int type;
    struct hashent* sadr;

    /* Check for a typedef */
    if (curtok == TYPEDEF) {
	gettok ();
	type = gettype (T_INT, &sadr);
	if ((*psym = declare (tarray, type, sadr, 0)) == 0) {
	    /* Identifier missing */
	    Error (ERR_IDENT_EXPECTED);
	} else {
       	    ConsumeSemi ();
	}
	return 1;
    }

    /* No typedef */
    return 0;
}



unsigned getsclass (int level, unsigned dflt)
/* Process "<storage-class>" */
{
    switch (curtok) {

    	case EXTERN:
    	    gettok ();
    	    return (SC_EXTERN | SC_STATIC);
    	    break;

    	case STATIC:
    	    gettok ();
    	    return SC_STATIC;

    	case REGISTER:
    	    gettok ();
    	    if (level == 0) {
    	 	Error (ERR_ILLEGAL_MODIFIER);
    	 	return SC_STATIC;
    	    }
    	    return SC_REGISTER | SC_STATIC;

    	case AUTO:
    	    gettok ();
    	    if (level == 0) {
    	 	Error (ERR_ILLEGAL_MODIFIER);
    	 	return SC_STATIC;
    	    }
    	    return SC_STACK;

    	default:
    	    return dflt | SC_DEFAULT;
    }
}



struct hashent* declare (type* ptyp, type t, struct hashent* sadr, int mode)
/* Construct a type array. */
{
    struct hashent *psym;
    type* tarray;

    /* Get additional declarators */
    psym = decl (&ptyp, mode);

    /* Add the base type. Special handling for typedefs here */
    if (t == T_TYPEDEF) {
	/* Add the def'd type. */
	tarray = (sadr->h_loc == SC_TYPEDEF)? sadr->h_ltptr : sadr->h_gtptr;
	TypeCpy (ptyp, tarray);
	ptyp += TypeLen (tarray);
    } else {
        *ptyp++ = t;
    }
    if (t == T_STRUCT || t == T_UNION) {
	/* Encode the field list in the type spec */
	encode (ptyp, (unsigned) sadr);
	ptyp += DECODE_SIZE;
    }
    *ptyp = T_END;
    return psym;
}



type gettype (int dflt, struct hashent **sptr)
/* gettype( dflt ) Process "<type>" */
{
    struct hashent* psym;
    int strtype;
    int sz;

    /* Skip const or volatile modifiers if needed */
    optional_modifiers ();

    /* Look at the data type */
    switch (curtok) {

    	case VOID:
    	    gettok ();
    	    return T_VOID;

    	case CHAR:
    	    gettok ();
    	    return T_UCHAR;		/* Default char is unsigned */

    	case LONG:
    	    gettok ();
    	    if (curtok == UNSIGNED) {
    	     	gettok ();
    	     	optionalint ();
    	     	return T_ULONG;
    	    } else {
    	   	optionalsigned ();
    	     	optionalint ();
       	        return T_LONG;
    	    }

    	case SHORT:
    	    gettok ();
    	    if (curtok == UNSIGNED) {
    	   	gettok ();
    	   	optionalint ();
    	   	return T_USHORT;
    	    } else {
    		optionalsigned ();
    		optionalint ();
    		return T_SHORT;
    	    }

    	case INT:
    	    gettok ();
    	    return T_INT;

       case SIGNED:
    	    gettok ();
    	    switch (curtok) {

       		case CHAR:
    		    gettok ();
    		    return T_CHAR;

    		case SHORT:
    		    gettok ();
    		    optionalint ();
    		    return T_SHORT;

    		case LONG:
    		    gettok ();
    		    optionalint ();
    		    return T_LONG;

    		case INT:
    		    gettok ();
    		    /* FALL THROUGH */

    		default:
    		    return T_INT;
    	    }

    	case UNSIGNED:
    	    gettok ();
    	    switch (curtok) {

    		case CHAR:
    		    gettok ();
    		    return T_UCHAR;

    		case SHORT:
    		    gettok ();
    		    optionalint ();
    		    return T_USHORT;

    		case LONG:
    		    gettok ();
    		    optionalint ();
    		    return T_ULONG;

    		case INT:
    		    gettok ();
    		    /* FALL THROUGH */

    		default:
       		    return T_UINT;
    	    }


    	case STRUCT:
    	case UNION:
    	    strtype = curtok == STRUCT ? T_STRUCT : T_UNION;
    	    gettok ();
    	    if (curtok == IDENT) {
    		*sptr = (struct hashent*) curval;
    		gettok ();
    	    } else {
    		*sptr = xmalloc (sizeof (struct hashent));
    		memset (*sptr, 0, sizeof (struct hashent));
    	    }
    	    sz = declstruct (*sptr, strtype);
    	    addstag (*sptr, sz);
    	    return strtype;

    	case ENUM:
    	    gettok ();
	    if (curtok != LCURLY) {
		/* Named enum */
    	        Consume (IDENT, ERR_IDENT_EXPECTED);
	    }
    	    declenum ();
    	    return T_INT;

        case IDENT:
    	    psym = (struct hashent*) curval;
       	    if (istypedef (psym)) {
    	      	/* Yup, it's a typedef */
    	      	gettok ();
    	      	*sptr = psym;
    	      	return T_TYPEDEF;
    	    }
    	    /* FALL THROUGH */

    	default:
    	    if (dflt < 0) {
    		Error (ERR_TYPE_EXPECTED);
		return T_INT;
    	    } else {
    	        return dflt;
	    }
    }
}



void ptype (struct hashent *psym, type* tarray)
/* Output translation of type array. */
{
    type* p;

    printf ("%s: ", psym ? psym->h_name : "<>");
    for (p = tarray; *p != '\0'; ++p) {
	if (*p & T_UNSIGNED) {
	    printf ("unsigned ");
	}
	switch (*p) {
    	    case T_VOID:
	  	printf ("void\n");
	  	break;
	    case T_CHAR:
	    case T_UCHAR:
	  	printf ("char\n");
	  	break;
	    case T_INT:
	    case T_UINT:
	  	printf ("int\n");
	  	break;
	    case T_SHORT:
	    case T_USHORT:
	    	printf ("short\n");
	    	break;
	    case T_LONG:
	    case T_ULONG:
	     	printf ("long\n");
	     	break;
	    case T_FLOAT:
	     	printf ("float\n");
	     	break;
	    case T_DOUBLE:
	     	printf ("double\n");
	     	break;
	    case T_PTR:
	     	printf ("ptr to ");
	     	break;
	    case T_ARRAY:
	     	printf ("array[%d] of ", decode (p + 1));
	     	p += DECODE_SIZE;
	     	break;
	    case T_STRUCT:
	     	printf ("struct %s\n", ((struct hashent*) decode (p + 1))->h_name);
	     	p += DECODE_SIZE;
	     	break;
	    case T_UNION:
	     	printf ("union %s\n", ((struct hashent*) decode (p + 1))->h_name);
	     	p += DECODE_SIZE;
	     	break;
            case T_FUNCF:
	     	printf ("fastcall ");
	     	/* FALLTHROUGH */
	    case T_FUNC:
	    case T_FUNCN:
	     	printf ("function returning ");
	     	p += DECODE_SIZE;
	     	break;
	    default:
	     	printf ("unknown type: %04X\n", *p);
	}
    }
}



void parseinit (type *tptr)
/* Parse initialization of variables */
{
    int count;
    struct expent lval;
    struct hashent *p;
    struct hashent *q;
    type* t;
    char* str;
    int sz;

    switch (*tptr) {

     	case T_CHAR:
     	case T_UCHAR:
     	    constexpr (&lval);
	    if ((lval.e_flags & E_MCTYPE) == E_TCONST) {
	    	/* Make it byte sized */
	    	lval.e_const &= 0xFF;
	    }
	    g_bytepref ();
     	    outconst (&lval);
     	    break;

    	case T_SHORT:
    	case T_USHORT:
     	case T_INT:
     	case T_UINT:
     	case T_PTR:
     	    constexpr (&lval);
	    if ((lval.e_flags & E_MCTYPE) == E_TCONST) {
	    	/* Make it word sized */
	    	lval.e_const &= 0xFFFF;
	    }
	    g_wordpref ();
     	    outconst (&lval);
     	    break;

    	case T_LONG:
    	case T_ULONG:
	    constexpr (&lval);
	    g_longpref ();
     	    outconst (&lval);
     	    break;

     	case T_ARRAY:
     	    sz = decode (tptr + 1);
	    t = tptr + DECODE_SIZE + 1;
       	    if ((t [0] == T_CHAR || t [0] == T_UCHAR) && curtok == SCONST) {
     	     	str = litpool + curval;
     	     	count = strlen (str) + 1;
	    	littrans (curval);   	/* Translate into target charset */
     	     	g_defbytes (str, count);
     	     	litptr = curval;     	/* Remove string from pool */
     	     	gettok ();
     	    } else {
     	     	ConsumeLCurly ();
     	     	count = 0;
     	     	while (curtok != RCURLY) {
     	     	    parseinit (tptr + DECODE_SIZE + 1);
     	     	    ++count;
     	     	    if (curtok != COMMA)
     	     	 	break;
     	     	    gettok ();
     	     	}
     	     	ConsumeRCurly ();
     	    }
     	    if (sz == 0) {
     	     	encode (tptr + 1, count);
     	    } else if (count < sz) {
     	     	g_zerobytes ((sz - count) * SizeOf (tptr + DECODE_SIZE + 1));
     	    } else if (count > sz) {
     	     	Error (ERR_TOO_MANY_INITIALIZERS);
     	    }
     	    break;

        case T_STRUCT:
        case T_UNION:
     	    ConsumeLCurly ();
     	    q = (struct hashent*) decode (tptr + 1);
     	    p = q->h_link;
     	    while (curtok != RCURLY) {
     	     	if (p == NULL) {
		    Error (ERR_TOO_MANY_INITIALIZERS);
     	     	    return;
     	     	}
     	     	parseinit (p->h_gtptr);
     	     	p = p->h_link;
     	     	if (curtok != COMMA)
     	     	    break;
     	     	gettok ();
     	    }
     	    ConsumeRCurly ();
     	    while (p != NULL) {
     	     	g_zerobytes (SizeOf (p->h_gtptr));
     	     	p = p->h_link;
     	    }
     	    break;

     	default:
	    Internal ("Unknown type: %04X", *tptr);

    }
}



