/*
 * function.c
 *
 * Ullrich von Bassewitz, 03.08.1998
 */



#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "datatype.h"
#include "global.h"
#include "util.h"
#include "mem.h"
#include "error.h"
#include "check.h"
#include "scanner.h"
#include "symtab.h"
#include "declare.h"
#include "expr.h"
#include "stmt.h"
#include "codegen.h"
#include "litpool.h"
#include "function.h"



/*****************************************************************************/
/*	     			     data				     */
/*****************************************************************************/



/* Maximum local variable count. The actual count is usually less than this,
 * since we have another maximum of 256 bytes of local space. The value below
 * is used as the dimension for arrays of local variables.
 */
#define	MAX_LOCALS	256

/* Return type of the current function */
type* funcreturn = 0;

/* Is the current function one without a return value? */
int voidfunc = 0;

/* Number of arguments and size of arguments for the current function */
unsigned ParamSize  = 0;
unsigned ParamCount = 0;

/* Register variable management */
unsigned MaxRegSpace 	    	= 6; 	/* Maximum space available */
static int RegOffs     	       	= 0;	/* Offset into register space */
static struct hashent** RegSyms	= 0;    /* The register variables */
static unsigned RegSymCount 	= 0;    /* Number of register variables */



/*****************************************************************************/
/*  	     	 	    	     code	      			     */
/*****************************************************************************/



static void DoneRegVars (void)
/* Free the register variables */
{
    xfree (RegSyms);
    RegSyms = 0;
    RegOffs = MaxRegSpace;
    RegSymCount = 0;
}



static void InitRegVars (void)
/* Initialize register variable control data */
{
    /* If the register space is zero, bail out */
    if (MaxRegSpace == 0) {
	return;
    }

    /* The maximum number of register variables is equal to the register
     * variable space available. So allocate one pointer per byte. This
     * will usually waste some space but we don't need to dynamically
     * grow the array.
     */
    RegSyms = xmalloc (MaxRegSpace * sizeof (struct hashent*));
    RegOffs = MaxRegSpace;
}



static int AllocRegVar (struct hashent* Sym, const type* tarray)
/* Allocate a register variable with the given amount of storage. If the
 * allocation was successful, return the offset of the register variable in
 * the register bank (zero page storage). If there is no register space left,
 * return -1.
 */
{
    /* Maybe register variables are disabled... */
    if (EnableRegVars) {

	/* Get the size of the variable */
	unsigned Size = SizeOf (tarray);

	/* Do we have space left? */
	if (RegOffs >= Size) {

	    /* Space left. We allocate the variables from high to low addresses,
	     * so the adressing is compatible with the saved values on stack.
	     * This allows shorter code when saving/restoring the variables.
	     */
	    RegOffs -= Size;
	    RegSyms [RegSymCount++] = Sym;
	    return RegOffs;
	}
    }

    /* No space left or no allocation */
    return -1;
}



static void ParseFuncArgsOldStyle (type** signature, int* varparam)
/* Parse function dummy arguments old style type, return signature and
 * marker if a variable parameter list was found.
 */
{
    int I;
    unsigned PCount;
    unsigned PSize;
    struct hashent* psym;
    struct hashent* sadr;
    type tarray [MAXTYPELEN];
    type *tptr;
    int sc;
    int type;
    int offs;
    int localstart;

    /* K&R functions may always be called with variable parameter lists */
    *varparam = 1;

    /* Remember the local variable pointer at start of the function */
    localstart = lovptr;

    /* Parse params */
    PCount = PSize = 0;
    while (1) {

       	/* We expect identifiers only */
       	if (curtok == IDENT) {

       	    /* Get the symbol table entry */
       	    psym = (struct hashent*) curval;

       	    /* Add it to the local symbol table with a default int type */
       	    addloc (psym, type_int, SC_STACK | SC_DEFINED | SC_PARAM, 0);

       	    /* Skip the identifier */
       	    gettok ();

       	} else {

       	    Error (ERR_IDENT_EXPECTED);

       	}

       	/* Check for more parameters */
       	if (curtok == COMMA) {
       	    gettok ();
       	} else {
       	    break;
       	}
    }

    /* Check and skip right paren. */
    ConsumeRParen ();

    /* If this is not a real function but only a type, remove the local
     * symbols and print a warning, since old style functions are not
     * useable as prototypes.
     */
    if (curtok == SEMI) {

	/* Just a type */
	Error (ERR_OLD_STYLE_PROTO);
	while (lovptr > localstart) {
	    psym = lvtab [--lovptr];
	    psym->h_loc = 0;
	}

    } else {

	while (curtok != LCURLY) {

	    /* Parse type assignments. First, read the storage class (default
	     * to stack). We will ignore the actual return value since all
	     * parameters have storage class auto (that is, they are on the
	     * stack).
	     */
	    getsclass (1, SC_STACK);

	    /* Read the type specifier. Pass T_EMPTY as default type to
	     * gettype, so we know, if we get this type, a type specifier
	     * was not found.
	     */
	    type = gettype (T_EMPTY, &sadr);
	    if (type == T_EMPTY) {
	     	Error (ERR_TYPE_EXPECTED);
	     	type = T_INT;
	    }

	    /* Read a comma separated list of declarations */
	    while (1) {

		/* Read the remaining type specifiers and the name */
		sc = SC_STACK | SC_DEFINED;
		if ((psym = declare (tarray, type, sadr, 2)) != NULL) {

		    /* Search for this parameter */
		    for (I = localstart; I < lovptr; ++I) {
		       	if (lvtab [I] == psym) {
		       	    break;
		       	}
		    }

		    /* Did we find it? */
		    if (I >= lovptr) {
		       	/* No such parameter */
		       	Error (ERR_PARAM_DECL, psym->h_name);

		       	/* Add this parameter to avoid problems later */
		       	addloc (psym, type_int, SC_STACK | SC_DEFINED | SC_PARAM, 0);
		    }

		    /* If the parameter is an array, convert it to a pointer */
		    tptr = TypeDup (tarray);
		    if (tptr[0] == T_ARRAY) {
		       	(tptr += DECODE_SIZE)[0] = T_PTR;
		    }

		    /* Assign the new type */
		    psym->h_ltptr = tptr;

		    /* Count arguments */
		    ++PCount;
		    PSize += SizeOf (tptr);
		}

		/* Break if no comma */
		if (curtok == COMMA) {
		    gettok ();
		} else {
		    break;
		}

	    }

	    /* Must have a semicolon */
	    ConsumeSemi ();
	}
    }

    /* Assign offsets. For old style functions there is always an additional
     * byte on the stack containing the argument size.
     */
    offs = 1;
    for (I = lovptr - 1; I >= localstart; --I) {
     	psym = lvtab[I];
     	psym->h_ldata = offs;
       	offs += SizeOf (psym->h_ltptr);
    }

    /* Put the calculated parameter count and size into the global variables */
    ParamCount = PCount;
    ParamSize  = PSize;

    /* The signature of an old style declared function is the same as a
     * function with an empty parameter list.
     */
    *signature = TypeDup (type_empty);
}



void ParseFuncArgs (type** signature, int* varparam)
/* Parse function dummy arguments, return signature and marker if a variable
 * parameter list was found.
 */
{
    /* Counter to make names of unnamed parameters */
    static unsigned unnamed = 0;

    int i;
    unsigned UnnamedCount = 0;
    unsigned PCount;
    unsigned PSize;
    struct hashent* psym;
    struct hashent* sadr;
    type tarray [MAXTYPELEN];
    type sign [4*MAXTYPELEN];
    type *tptr;
    int sc;
    int type;
    int offs;
    int localstart;

    /* Assume there's no ellipsis */
    *varparam = 0;

    /* Remember the local variable pointer at start of the function */
    localstart = lovptr;

    /* Setup the signature */
    sign [0] = T_END;
    if (curtok == RPAREN) {
       	TypeCpy (sign, type_empty);
 	*varparam = 1;
    }

    /* Parse params */
    PCount = PSize = 0;
    while (curtok != RPAREN) {

      	/* Allow an ellipsis as last parameter */
	if (curtok == ELLIPSIS) {
	    gettok ();
	    TypeCat (sign, type_ellipsis);
	    *varparam = 1;
	    break;
	}

	/* Read the storage class (default to stack). Ignore the actual
	 * value, since parameters are always on the stack.
	 */
	getsclass (1, SC_STACK);

	/* Read the type specifier. Pass T_EMPTY as default type to
	 * gettype, so we know, if we get this type, a type specifier
	 * was not found.
	 */
	type = gettype (T_EMPTY, &sadr);

	/* Special handling if this is the first parameter */
	if (PCount == 0) {

	    if (type == T_VOID && curtok == RPAREN) {
		/* Allow functions with void param list */
		TypeCat (sign, type_void);
		break;
	    } else if (type == T_EMPTY) {
		/* If the first parameter doesn't have a type specifier,
		 * assume an old style parameter list.
		 */
		ParseFuncArgsOldStyle (signature, varparam);
	 	return;
	    }

	} else {

	    /* 2... parameter */
	    if (type == T_EMPTY) {
		Error (ERR_TYPE_EXPECTED);
		type = T_INT;
	    }

	}

	/* Allow parameters without a name, but remember if we had some to
      	 * eventually print an error message later.
	 */
	sc = SC_STACK | SC_DEFINED;
	if ((psym = declare (tarray, type, sadr, 2)) == NULL) {
	    /* Unnamed symbol. Generate a name that is not user accessible,
	     * then handle the symbol normal.
	     */
	    char symname [20];
	    ++UnnamedCount;
	    sprintf (symname, "@%X", unnamed++);
	    psym = addsym (symname);
	    sc &= ~SC_DEFINED;      	/* Clear defined bit on nonames */
	}

	/* Create a symbol table entry */
	addloc (psym, tarray, sc | SC_PARAM, 0);

	/* If the parameter is an array, convert it to a pointer */
	tptr = TypeDup (tarray);
	if (tptr[0] == T_ARRAY) {
	    (tptr += DECODE_SIZE)[0] = T_PTR;
	}
	psym->h_ltptr = tptr;

	/* Add this parameter to the function signature */
	TypeCat (sign, tptr);

	/* Count arguments */
	++PCount;
	PSize += SizeOf (tptr);

	/* Check for more parameters */
	if (curtok == COMMA) {
	    gettok ();
	} else {
	    break;
	}
    }

    /* Skip right paren. We must explicitly check for one here, since some of
     * the breaks above bail out without checking.
     */
    ConsumeRParen ();

    /* Assign offsets. If the function has a variable parameter list,
     * there's one additional byte (the arg size).
     */
    offs = (*varparam != 0)? 1 : 0;
    for (i = lovptr - 1; i >= localstart; --i) {
     	psym = lvtab[i];
     	psym->h_ldata = offs;
       	offs += SizeOf (psym->h_ltptr);
    }

    /* If this is not a real function but only a type, remove the local
     * symbols.
     */
    if (curtok != LCURLY) {
	/* Just a type */
	while (lovptr > localstart) {
	    psym = lvtab [--lovptr];
	    psym->h_loc = 0;
	}
    } else {
	/* Print an error if in strict ANSI mode and we have unnamed
	 * parameters.
	 */
	if (ANSI && UnnamedCount > 0) {
	    Error (ERR_MISSING_PARAM_NAME);
	}
    }

    /* Put the calculated parameter count and size into the global variables */
    ParamCount = PCount;
    ParamSize  = PSize;

    /* Return a copy of the parameter signature on the heap */
    *signature = TypeDup (sign);
}



void NewFunc (struct hashent* psym)
/* Parse argument declarations and function body. */
{
    int isbrk;

    /* Function body now defined */
    psym->h_glb |= SC_DEFINED;

    /* Set the return type of the function */
    funcreturn = psym->h_gtptr + DECODE_SIZE + 1;

    /* Set a flag if the function is a void function */
    voidfunc = IsVoid (funcreturn);

    /* Need a starting curly brace */
    if (curtok != LCURLY) {
    	Error (ERR_LCURLY_EXPECTED);
    }

    /* Setup register variables */
    InitRegVars ();

    /* Switch to the code segment and generate function entry code */
    g_usecode ();
    g_enter (TypeOf (psym->h_gtptr), psym->h_name, ParamSize);

    /* Parse the function body */
    oursp = 0;
    isbrk = compound ();

    /* If the function did not end with an return statement, create exit code */
    if (!isbrk) {
	RestoreRegVars (0);
        g_leave (CF_NONE, 0);
    }

    /* Dump literal data created by the function */
    dumplits ();

    /* Reset the result pointer */
    funcreturn = 0;

    /* Cleanup register variables */
    DoneRegVars ();
}



void DeclareLocals (void)
/* Declare local variables and types. */
{
    int offs = oursp; 	      	/* Current stack offset for variable */
    int AutoSpace = 0;		/* Unallocated space on the stack */
    int Size;	      	      	/* Size of an auto variable */
    int Reg; 	      		/* Register variable offset */
    unsigned flags = 0;		/* Code generator flags */
    int sc;  	      		/* Storage class read */
    int SymbolSC;		/* Storage class for symbol */
    type tarray[MAXTYPELEN];	/* Type array */
    int type;	      		/* Variable type specifier */
    int ldata = 0;    		/* Local symbol data temp storage */
    struct hashent* psym;
    struct hashent* sadr;


    /* Loop until we don't find any more variables */
    while (1) {

	/* check for a typedef */
     	if (gettypedef (&psym, tarray) && psym) {
	    /* Got a typedef, add it to the local symbol table */
	    addloc (psym, tarray, SC_TYPEDEF, 0);
     	    continue;
	}

	/* Check variable declarations. We need to distinguish between a
	 * default int type and the end of variable declarations. So we
	 * will do the following: If an explicit storage class specifier
	 * was found, default to int, else default to zero and end variable
	 * parsing if we get the zero back.
	 */
    	sc = getsclass (1, SC_STACK);
       	type = (sc & SC_DEFAULT)? 0 : T_INT;
     	if ((type = gettype (type, &sadr)) == 0) {
     	    break;
 	}

	if (curtok == SEMI) {
	    /* Type declaration only */
	    gettok ();
	    continue;
	}

	/* Parse a comma separated variable list */
     	while (1) {

	    /* Remember the storage class for the new symbol */
	    SymbolSC = sc;

	    /* Read the declaration */
     	    psym = declare (tarray, type, sadr, 0);

       	    if (!IsFunc (tarray)) {

	     	/* Get the size of the variable */
	     	Size = SizeOf (tarray);

    	      	/* Check the storage class */
    	      	if ((SymbolSC & SC_REGISTER) && (Reg = AllocRegVar (psym, tarray)) >= 0) {

    	      	    /* We will store the current value of the register onto the
    	      	     * stack, thus making functions with register variables
    	      	     * reentrant. If we have pending auto variables, emit them
    	     	     * now.
    	      	     */
    	      	    g_usecode ();
    	     	    g_space (AutoSpace);
    	     	    oursp -= AutoSpace;
    	     	    AutoSpace = 0;

    	     	    /* Remember the register bank offset */
    	     	    ldata = Reg;

    	     	    /* Save the current register value onto the stack */
    	     	    g_save_regvars (Reg, Size);

    	     	    /* Allow variable initialization */
    	      	    if (curtok == ASGN) {

    	      	       	struct expent lval;

    	      	       	/* Skip the '=' */
    	      	       	gettok ();

    	      	       	/* Get the expression into the primary */
	    		expression1 (&lval);

    	     		/* Make type adjustments if needed */
    	     		assignadjust (tarray, &lval);

    	      	     	/* Setup the type flags for the assignment */
			flags = TypeOf (tarray) | CF_REGVAR;
			if (Size == 1) {		    
			    flags |= CF_FORCECHAR;
			}

       	       	       	/* Store the value into the register */
       	       	       	g_putstatic (flags, Reg, 0);

    	      	       	/* Mark the variable as referenced */
    	      	       	SymbolSC |= SC_REF;

    	     	    }

    	     	    /* Account for the stack space needed and remember the
    	     	     * stack offset of the save area.
    	     	     */
    	     	    offs -= Size;
    	     	    psym->h_lattr = offs;

     	      	} else if (SymbolSC & (SC_STACK | SC_REGISTER)) {

    	     	    /* Auto variable */
      	     	    SymbolSC = SC_STACK;     	/* In case it was register */
    	      	    if (curtok == ASGN) {

    	      	       	struct expent lval;

    	     	     	/* Switch to the code segment, allocate space for
    	     		 * uninitialized variables.
	     		 */
	     	     	g_usecode ();
	     		g_space (AutoSpace);
	     		oursp -= AutoSpace;
	     		AutoSpace = 0;

	      	     	/* Skip the '=' */
	      	     	gettok ();

    	      	     	/* Setup the type flags for the assignment */
	      	     	flags = Size == 1? CF_FORCECHAR : CF_NONE;

	      	   	/* Get the expression into the primary */
	      	   	if (evalexpr (flags, hie1, &lval) == 0) {
	      	       	    /* Constant expression. Adjust the types */
	      	   	    assignadjust (tarray, &lval);
	      	   	    flags |= CF_CONST;
	      	   	} else {
	      	   	    /* Expression is not constant and in the primary */
	      	   	    assignadjust (tarray, &lval);
	      	   	}

       	       	       	/* Push the value */
	      	   	g_push (flags | TypeOf (tarray), lval.e_const);

	      		/* Mark the variable as referenced */
    	      	       	SymbolSC |= SC_REF;

	      	    } else {
	      		/* Non-initialized local variable. Just keep track of
	     		 * the space needed.
	     		 */
	     		AutoSpace += Size;
    	      	    }

	     	    /* Allocate space on the stack, assign the offset */
	     	    offs -= Size;
	     	    ldata = offs;

     	       	} else if (sc == SC_STATIC) {

	      	    /* Static data */
     	      	    if (curtok == ASGN) {

    	      	  	/* Initialization ahead, switch to data segment */
      	      	  	g_usedata ();

	      	  	/* Define the variable label */
     	      	        g_defloclabel (ldata = getlabel ());

	      	      	/* Skip the '=' */
     	      	       	gettok ();

     	      	       	/* Allow initialization of static vars */
     	      	       	parseinit (tarray);

	      		/* Mark the variable as referenced */
    	      	       	SymbolSC |= SC_REF;

     	      	    } else {

	      	  	/* Uninitialized data, use BSS segment */
	      	  	g_usebss ();

	      	       	/* Define the variable label */
     	      	        g_defloclabel (ldata = getlabel ());

	      	       	/* Reserve space for the data */
     	      	       	g_res (Size);

     	      	    }
     	      	}
       	    }

 	    addloc (psym, tarray, SymbolSC | SC_DEFINED, ldata);

     	    if (curtok != COMMA) {
     	      	break;
	    }
     	    gettok ();
       	}
     	if (curtok == SEMI) {
     	    gettok ();
     	}
    }

    /* In case we switched away from code segment, switch back now */
    g_usecode ();

    /* Create space for locals */
    g_space (AutoSpace);
    oursp -= AutoSpace;
}



void RestoreRegVars (int HaveResult)
/* Restore the register variables for the local function if there are any.
 * The parameter tells us if there is a return value in ax, in that case,
 * the accumulator must be saved across the restore.
 */
{
    int I, J, Bytes, Offs;

    /* If we don't have register variables in this function, bail out early */
    if (RegSymCount == 0) {
    	return;
    }

    /* Save the accumulator if needed */
    if (!voidfunc && HaveResult) {
     	g_save (CF_CHAR | CF_FORCECHAR);
    }

    /* Walk through all variables. If there are several variables in a row
     * (that is, with increasing stack offset), restore them in one chunk.
     */
    I = 0;
    while (I < RegSymCount) {

	/* Check for more than one variable */
	struct hashent* Sym = RegSyms[I];
	Offs  = Sym->h_lattr;
	Bytes = SizeOf (Sym->h_ltptr);
	J = I+1;

       	while (J < RegSymCount) {

	    /* Get the next symbol */
	    struct hashent* NextSym = RegSyms [J];

	    /* Get the size */
	    int Size = SizeOf (NextSym->h_ltptr);

	    /* Adjacent variable? */
	    if (NextSym->h_lattr + Size != Offs) {
	      	/* No */
	      	break;
	    }

	    /* Adjacent variable */
	    Bytes += Size;
	    Offs  -= Size;
	    Sym   = NextSym;
	    ++J;
	}

	/* Restore the memory range */
       	g_restore_regvars (Offs, Sym->h_ldata, Bytes);

	/* Next round */
	I = J;
    }

    /* Restore the accumulator if needed */
    if (!voidfunc && HaveResult) {
     	g_restore (CF_CHAR | CF_FORCECHAR);
    }
}



static int HasEncode (type* Type)
/* Return true if the given type has encoded data */
{
    return IsStruct (Type) || IsArray (Type) || IsFunc (Type);
}



type* GetArgs (type* tptr)
/* Given a function or pointer to function, return a pointer to the
 * argument list.
 */
{
    if (*tptr == T_PTR) {
    	/* Pointer to function? */
     	++tptr;
    }

    /* Check the parameter */
    CHECK (IsFunc (tptr));

    /* Return the argument list */
    return (type*) decode (tptr+1);
}



type* NextArg (type* arglist, type* argbuf)
/* Given an argument list for a function, copy the next argument into argbuf
 * and return a pointer to the next argument. If the argument list is the
 * ellipsis (that is, any number of arguments are allowed), T_ELLIPSIS is
 * copied into the buffer, but the pointer is not incremented.
 */
{
    type t;

    /* The list may not be empty */
    CHECK (*arglist != T_END);

    /* Copy the next argument */
    if (*arglist == T_ELLIPSIS || *arglist == T_EMPTY) {
	*argbuf++ = T_ELLIPSIS;
    } else {
	while (1) {
	    type* TypePtr = arglist;
	    t = *arglist++;
	    *argbuf++ = t;

       	    if (HasEncode (TypePtr)) {
	       	/* Some encoded stuff follows */
	       	unsigned i;
	       	for (i = 0; i < DECODE_SIZE; i++) {
	       	    *argbuf++ = *arglist++;
	       	}
		/* If this is a struct, we're done */
		if (IsStruct (TypePtr)) {
		    break;
		}
	    } else if (t == T_VOID || (t & T_INTEGER) != 0 || (t & T_REAL) != 0) {
	       	break;
	    }
       	}
    }

    /* Add a trailing zero */
    *argbuf = T_END;

    /* Return the pointer to the next argument */
    return arglist;
}





