/*
 * function.h
 *
 * Ullrich von Bassewitz, 07.06.1998
 */



#ifndef FUNCTION_H
#define FUNCTION_H



#include "symtab.h"



/*****************************************************************************/
/*			  	     data				     */
/*****************************************************************************/



/* Return type of the current function */
extern type* funcreturn;

/* Is the current function one without a return value? */
extern int voidfunc;

/* Number of arguments and size of arguments for the current function */
extern unsigned ParamSize;
extern unsigned ParamCount;



/*****************************************************************************/
/*	   			     code				     */
/*****************************************************************************/



void ParseFuncArgs (type** signature, int* varparam);
/* Parse function dummy arguments, return signature and marker if a variable
 * parameter list was found.
 */

void NewFunc (struct hashent* psym);
/* Parse argument declarations and function body. */

void DeclareLocals (void);
/* Declare local variables and types. */

void RestoreRegVars (int HaveResult);
/* Restore the register variables for the local function if there are any.
 * The parameter tells us if there is a return value in ax, in that case,
 * the accumulator must be saved across the restore.
 */
type* GetArgs (type* tptr);
/* Given a function or pointer to function, return a pointer to the
 * argument list.
 */

type* NextArg (type* arglist, type* argbuf);
/* Given an argument list for a function, copy the next argument into argbuf
 * and return a pointer to the next argument. If the argument list is the
 * ellipsis (that is, any number of arguments are allowed), T_ELLIPSIS is
 * copied into the buffer, but the pointer is not incremented.
 */



/* End of function.h */
#endif





