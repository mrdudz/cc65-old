
/* Symbol table manipulation routines */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#include "global.h"
#include "error.h"
#include "io.h"
#include "mem.h"
#include "util.h"
#include "check.h"
#include "datatype.h"
#include "declare.h"
#include "codegen.h"
#include "symtab.h"



/*****************************************************************************/
/*		      	   	     data				     */
/*****************************************************************************/



/* Local variable table and number of locals */
struct hashent* lvtab [128];
int lovptr = 0;

/* The symbol table */
#define SYMBOL_TAB_SIZE	211
static struct hashent* SymTab [SYMBOL_TAB_SIZE];

/* Single linked list of global symbols */
static struct hashent* glvptr = 0;

/* Remember the last hash value so we don't have to calculate it twice */
static unsigned HashVal;



/*****************************************************************************/
/*		      		     code				     */
/*****************************************************************************/



struct hashent* FindStructField (type* TypeArray, const char* Name)
/* Find a struct field in the fields list */
{
    struct hashent* Sym;

    /* The given type may actually be a pointer to struct */
    if (*TypeArray == T_PTR) {
	++TypeArray;
    }

    /* Non-structs do not have any struct fields... */
    if (IsStruct (TypeArray)) {

	/* Get a pointer to the struct/union type */
     	Sym = (struct hashent*) decode (TypeArray+1);
	CHECK (Sym != 0);

	/* Get a pointer to the first field */
	Sym = Sym->h_link;

     	/* Search in the single linked symbol list */
     	while (Sym) {
     	    if (strcmp (Sym->h_name, Name) == 0) {
     		return Sym;
     	    }
     	    Sym = Sym->h_link;
     	}
    }
    return 0;
}



void addstag (struct hashent *psym, int sz)
/* Define a struct/union tag to the symbol table. */
{
    if (psym->h_glb != 0) {
     	/* tag already declared; check for multiple declare.
     	 * Beware of int promotion here!
     	 */
     	if (psym->h_glb != SC_STAG || (sz && psym->h_gdata)) {
     	    Error (ERR_MULTIPLE_DEFINITION);
     	}
     	/* define struct size if sz != 0 */
     	if (sz) {
     	    psym->h_gdata = sz;
     	}
     	return;
    }
    psym->h_glb = SC_STAG;
    psym->h_gdata = sz;
    return;
}



static struct hashent* findsym (const char* sym)
/* Look up sym in hash table and return ptr to entry. */
{
    struct hashent *p;

    HashVal = HashStr (sym) % SYMBOL_TAB_SIZE;
    for (p = SymTab [HashVal]; p != NULL; p = p->h_ptr) {
     	if (strcmp (p->h_name, sym) == 0) {
	    return p;
	}
    }
    return 0;
}



struct hashent* addsym (const char* sym)
/* Add a symbol to the symbol table. */
{
    struct hashent **hptr;
    struct hashent *psym;

    if ((psym = findsym (sym))) {
	return psym;
    }

    /* Create a new hash table entry */
    psym = xmalloc (sizeof (struct hashent) + strlen (sym));
    memset (psym, 0, sizeof (struct hashent));
    strcpy (psym->h_name, sym);

    /* Add a symbol entry to the hash table. hashval set by findsym above. */
    hptr = &SymTab [HashVal];
    psym->h_ptr = *hptr;
    return (*hptr = psym);
}



int EqualTypes (type* t1, type* t2)
/* Recursively compare two types. Return 1 if the types match, return 0
 * otherwise.
 */
{
    int v1, v2;
    struct hashent* sym1;
    struct hashent* sym2;


    /* Shortcut here: If the pointers are identical, the types are identical */
    if (t1 == t2) {
    	return 1;
    }

    /* Compare two types. Determine, where they differ */
    while (*t1 == *t2 && *t1 != T_END) {

    	switch (*t1) {

    	    case T_FUNC:
    	    case T_FUNCF:
    	    case T_FUNCN:
    	       	/* Recursively compare the function param */
       	       	if (!EqualTypes ((type*) decode (t1+1), (type*) decode (t2+1))) {
    	       	    /* Function given as param differs */
    	       	    return 0;
     	       	}
    	       	t1 += DECODE_SIZE;
    	       	t2 += DECODE_SIZE;
    	       	break;

    	    case T_ARRAY:
    		/* Check member count */
    		v1 = decode (t1+1);
    		v2 = decode (t2+1);
    		if (v1 != 0 && v2 != 0 && v1 != v2) {
    		    /* Member count given but different */
    		    return 0;
    		}
    		t1 += DECODE_SIZE;
     		t2 += DECODE_SIZE;
    	    	break;

    	    case T_STRUCT:
    	    case T_UNION:
       	       	/* Compare the fields recursively. To do that, we fetch the 
		 * pointer to the struct definition from the type, and compare
		 * the fields.
		 */
		sym1 = (struct hashent*) decode (t1+1);
		sym2 = (struct hashent*) decode (t2+1);
		
		/* The pointer pointer to the struct def, get the fields list */
		sym1 = sym1->h_link;
		sym2 = sym2->h_link;

		/* Compare the fields */
		while (sym1 && sym2) {

		    /* Compare this field */
		    if (!EqualTypes (sym1->h_gtptr, sym2->h_gtptr)) {
		     	/* Field types not equal */
		     	return 0;
		    }

		    /* Get the pointers to the next fields */
		    sym1 = sym1->h_link;
		    sym2 = sym2->h_link;
		}

		/* Check if there are any fields left (both ptrs must be NULL) */
		if (sym1 != sym2) {
		    /* One struct has more fields than the other */
		    return 0;
		}

		/* Structs are equal */
    		t1 += DECODE_SIZE;
    		t2 += DECODE_SIZE;
     		break;
    	}
    	++t1;
    	++t2;
    }

    if (*t1) {
    	/* Parameter lists differ */
    	if (*t1 != T_ELLIPSIS && *t1 != T_EMPTY) {
    	    /* The difference is not in a variable part */
    	    return 0;
    	}
    }

    /* Done, types are equal */
    return 1;
}



void addglb (struct hashent *psym, type* tarray, int sc)
/* Add a global symbol to the symbol table */
{
    type* tptr;
    int sz1;

    if (psym->h_glb != 0) {

       	/* Symbol entered previously. */
     	if (psym->h_glb & SC_TYPE) {
     	    Error (ERR_MULTIPLE_DEFINITION);
     	    return;
     	}
     	tptr = psym->h_gtptr;
     	if ((tarray[0] == T_ARRAY) &&
     	    (((sz1 = decode (tptr + 1)) == 0) ||
     	     (decode (tarray + 1) == 0))) {
     	    if (TypeCmp (tptr + DECODE_SIZE + 1, tarray + DECODE_SIZE + 1)) {
     	    	Error (ERR_MULTIPLE_DEFINITION);
     	    	return;
     	    }
     	    if (sz1 == 0) {
     	  	/* Array was previously defined without a size and the size
     	  	 * is now given. Fill in the size.
     	  	 */
     	  	encode (tptr + 1, decode (tarray + 1));
     	    }
     	} else if (IsFunc (tarray)) {

	    /* The old function may be an implcitly declared function, and the
	     * new one is the explicit definition. In this case, the entry we
	     * have in the symbol table has a type of T_FUNC, and the second
	     * one as a type of T_FUNCN/T_FUNCF. Allow this case, and use the
	     * new type in the entry we already have.
	     */
	    if (*tptr == T_FUNC && (*tarray == T_FUNCN || *tarray == T_FUNCF)) {
	  	*tptr = *tarray;
	    }

     	    /* Compare the types */
     	    if (!EqualTypes (tptr, tarray)) {
     	  	Error (ERR_FUNC_REDEFINITION);
     	  	return;
     	    }

	} else if (IsFuncPtr (tarray)) {

     	    /* Compare the types */
     	    if (!EqualTypes (tptr, tarray)) {
     	  	Error (ERR_FUNC_REDEFINITION);
     	  	return;
     	    }

     	} else if (TypeCmp (tptr, tarray) != 0) {
     	    Error (ERR_MULTIPLE_DEFINITION);
     	    return;
     	}
     	psym->h_glb |= sc;

    } else {

     	/* New symbol */
	tptr = TypeDup (tarray);

     	psym->h_glb   = sc;
     	psym->h_gtptr = tptr;
     	/* we always want symbol name, not internal cruft, so we just shove ptr
     	 * to start of name string in here instead of internal ident
     	 */
     	psym->h_gdata = (int) &psym->h_name;
       	psym->h_link  = glvptr;
     	glvptr = psym;
    }
}



void addloc (struct hashent* psym, type* tarray, int sc, int offs)
/* Add a local symbol. */
{
    type* tptr;

    /* Process function declarations and externs inside of function. */
    if (tarray && IsFunc (tarray)) {
     	if ((sc & (SC_DEFAULT | SC_EXTERN)) == 0) {
     	    Warning (WARN_FUNC_MUST_BE_EXTERN);
     	}
     	sc = SC_EXTERN;
    }
    if (sc & SC_EXTERN) {
     	addglb (psym, tarray, sc);
     	return;
    }
    if (psym->h_loc != 0) {
     	Error (ERR_MULTIPLE_DEFINITION);
     	return;
    }
    if (tarray != NULL) {
     	tptr = TypeDup (tarray);
    } else {
     	tptr = NULL;
    }

    psym->h_loc   = sc;
    psym->h_ltptr = tptr;
    psym->h_ldata = offs;

    lvtab[lovptr++] = psym;
}



void DropLocals (int Check)
/* Drop local variables, check for unused params if requested, emit code for
 * queued gotos (should be separate function...).
 */
{
    struct hashent* psym;
    struct hashent* Goto;
    struct hashent* p;
    unsigned sc;

    while (lovptr) {

	/* Get a pointer to the symbol and the storage class */
	psym = lvtab [--lovptr];
	sc = psym->h_loc;

       	if (Check) {

	    /* Check if the symbol is one with storage, and it if it was
	     * defined but not used.
	     */
	    if ((sc & SC_STACK) || (sc & SC_STATIC)) {
		if ((sc & SC_DEFINED) && !(sc & SC_REF)) {
		    if (sc & SC_PARAM) {
		       	Warning (WARN_UNUSED_PARM, psym->h_name);
		    } else {
		       	Warning (WARN_UNUSED_ITEM, psym->h_name);
		    }
		}
	    }

	    /* If the entry is a label, check if it was defined in the function */
	    if (sc & SC_LABEL) {
		if ((sc & SC_DEFINED) == 0) {
		    /* Undefined label */
		    Error (ERR_UNDEFINED_LABEL, psym->h_name);
	 	} else if ((sc & SC_REF) == 0) {
		    /* Defined but not used */
	 	    Warning (WARN_UNUSED_ITEM, psym->h_name);
	 	} else {
		    /* Defined and referenced. Check for queued gotos */
		    Goto = psym->h_link;
		    while (Goto) {
		       	if (Goto->h_loc) {
		       	    /* Valid label, emit code */
		       	    g_defloclabel (Goto->h_ldata);
		       	    g_space (Goto->h_lattr - psym->h_lattr);
		       	    g_jump (psym->h_ldata);
		       	}

		       	/* Free the entry, set pointer to next entry */
		       	p = Goto;
		       	Goto = Goto->h_link;
		       	xfree (p);

		    }
		}
	    }
	}

	/* Clear the entry */
	psym->h_loc = 0;
    }
}



void MakeZPSym (const char* Name)
/* Mark the given symbol as zero page symbol */
{
    /* Make/get a symbol table entry */
    struct hashent* Sym = addsym (Name);

    /* Mark the symbol as zeropage */
    if (Sym->h_loc != 0) {
     	Sym->h_loc |= SC_ZEROPAGE;
    } else {
        Sym->h_glb |= SC_ZEROPAGE;
    }
}



size_t SizeOf (const type* tarray)
/* Compute size of object represented by type array. */
{
    struct hashent *p;

    switch (*tarray) {

	case T_VOID:
	    return 0;

	case T_CHAR:
	case T_UCHAR:
	    return 1;

	case T_INT:
	case T_UINT:
       	case T_SHORT:
    	case T_USHORT:
	case T_PTR:
        case T_ENUM:
	    return 2;

        case T_LONG:
    	case T_ULONG:
	    return 4;

	case T_ARRAY:
	    return (decode (tarray + 1) * SizeOf (tarray + DECODE_SIZE + 1));

	case T_STRUCT:
	case T_UNION:
	    p = (struct hashent *) decode (tarray+1);
       	    return (p->h_gdata);

	default:
	    Internal ("Unknown type: %04X", *tarray);
	    return 0;

    }
}



size_t PSizeOf (const type* tptr)
/* Compute size of pointer object. */
{
    /* We are expecting a pointer expression */
    CHECK (*tptr & T_POINTER);

    /* Skip the pointer or array token itself */
    if (*tptr == T_ARRAY) {
       	return SizeOf (tptr + DECODE_SIZE + 1);
    } else {
      	return SizeOf (tptr + 1);
    }
}



unsigned TypeOf (const type* tptr)
/* Get the code generator base type of the object */
{
    switch (*tptr) {

    	case T_CHAR:
    	    return CF_CHAR;

    	case T_UCHAR:
    	    return CF_CHAR | CF_UNSIGNED;

    	case T_SHORT:
	case T_INT:
        case T_ENUM:
	    return CF_INT;

    	case T_USHORT:
	case T_UINT:
	case T_PTR:
    	case T_ARRAY:
	    return CF_INT | CF_UNSIGNED;

        case T_LONG:
	    return CF_LONG;

    	case T_ULONG:
	    return CF_LONG | CF_UNSIGNED;

        case T_FUNC:
	    return 0;

        case T_FUNCF:
        case T_FUNCN:
	    return CF_FIXARGC;

        case T_STRUCT:
        case T_UNION:
	    /* Address of ... */
	    return CF_INT | CF_UNSIGNED;

    	default:
	    Error (ERR_INVALID_TYPE, *tptr);
	    return T_INT;
    }
}



type* Indirect (type* tptr)
/* Do one indirection for the given type, that is, return the type where the
 * given type points to.
 */
{
    /* We are expecting a pointer expression */
    CHECK (*tptr & T_POINTER);

    /* Skip the pointer or array token itself */
    if (*tptr == T_ARRAY) {
       	return tptr + DECODE_SIZE + 1;
    } else {
      	return tptr + 1;
    }
}



int IsVoid (const type* tptr)
/* Return true if this is a void type */
{
    return (tptr [0] == T_VOID && tptr [1] == T_END);
}



int IsPtr (const type* tptr)
/* Return true if this is a pointer type */
{
    return (*tptr & T_POINTER) != 0;
}



int IsChar (const type* tptr)
/* Return true if this is a character type */
{
    return (tptr [0] == T_CHAR || tptr [0] == T_UCHAR) && tptr [1] == T_END;
}



int IsInt (const type* tptr)
/* Return true if this is an integer type */
{
    return (*tptr & T_INTEGER) != 0;
}



int IsLong (const type* tptr)
/* Return true if this is a long type (signed or unsigned) */
{
    return (*tptr & T_INTEGER) && (*tptr & T_LONG) == T_LONG;
}



int IsUnsigned (const type* tptr)
/* Return true if this is an unsigned type */
{
    return (*tptr & T_UNSIGNED) != 0;
}



int IsStruct (const type* tptr)
/* Return true if this is a struct type */
{
    type T = *tptr;
    return (T == T_STRUCT || T == T_UNION);
}



int IsFunc (const type* tptr)
/* Return true if this is a function type */
{
    return (*tptr == T_FUNC || *tptr == T_FUNCN || *tptr == T_FUNCF);
}



int IsFuncPtr (const type* tptr)
/* Return true if this is a function pointer */
{
    return (*tptr == T_PTR && IsFunc (tptr+1));
}



int IsArray (const type* tptr)
/* Return true if this is an array type */
{
    return (*tptr == T_ARRAY);
}



void dumpglbs (void)
/* Dump global symbol table, for debugging. */
{
    struct hashent *psym;

    if (Debug) {
	printf ("\nGlobal Symbol Table\n");
	printf ("===================\n");
	for (psym = glvptr; psym != 0; psym = psym->h_link) {
	    if (!(psym->h_glb & SC_TYPE)) {
       	        printf ("%02X, ", psym->h_glb);
	        ptype (psym, psym->h_gtptr);
	    }
	}
    }
}



void dumploc (struct hashent *pfunc)
/* Dump local symbol table, for debugging. */
{
    int i;
    struct hashent *psym;

    if (Debug) {
 	printf ("\nLocal Symbol Table for '%s'\n", pfunc->h_name);
 	printf ("==================================\n");
 	for (i = 0; i < lovptr; ++i) {
 	    psym = lvtab[i];
 	    if (!(psym->h_loc & SC_TYPE)) {
 		printf ("%02X, %4d, ", psym->h_loc, psym->h_ldata);
 		ptype (psym, psym->h_ltptr);
 	    }
 	}
    }
}



void PrintSymbolTable (FILE* F)
/* Write the symbol table to the given file */
{
    unsigned i;
    struct hashent *p;

    fprintf (F, "\n\n"
		"Symbol Hash Table Summary\n"
		"=========================\n");
    for (i = 0; i < SYMBOL_TAB_SIZE; ++i) {
	fprintf (F, "%4u: ", i);
	if (SymTab [i]) {
	    for (p = SymTab [i]; p != NULL; p = p->h_ptr) {
	     	fprintf (F, "%s ", p->h_name);
	    }
	    fprintf (F, "\n");
	} else {
	    fprintf (F, "empty\n");
	}
    }
}



void dumpnams (void)
/* dump names of globals */
{
    struct hashent *psym;
    unsigned sc;

    outline ("");
    for (psym = glvptr; psym != 0; psym = psym->h_link) {
	if ((sc = psym->h_glb) & SC_TYPE) {
	    continue;
	}
	if (sc & SC_EXTERN) {
	    /* Only defined or referenced externs */
	    if ((sc & SC_REF) != 0 && (sc & SC_DEFINED) == 0) {
		/* An import */
		g_defimport (psym->h_name, sc & SC_ZEROPAGE);
	    } else if (sc & SC_DEFINED) {
		/* An export */
		g_defexport (psym->h_name, sc & SC_ZEROPAGE);
	    }
	} else if (sc & SC_STATIC) {
	    if ((sc & SC_DEFINED) && !(sc & SC_REF)) {
	        Warning (WARN_UNUSED_ITEM, psym->h_name);
	    }
	}
    }
}



void dumpstruct (void)
/* Dump structs/unions. */
{
    if (Debug) {
	printf ("\nStruct/union Table\n");
	printf ("==================\n");
    }
}




