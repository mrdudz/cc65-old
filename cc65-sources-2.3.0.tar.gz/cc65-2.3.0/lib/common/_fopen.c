/*
 * _fopen.c
 *
 * Ullrich von bassewitz, 17.06.1997
 */



#include <fcntl.h>
#include "_file.h"



FILE* _fopen (char* name, char* mode, FILE* f)
/* Open the specified file and fill the descriptor values into f */
{
    /* Open the file */
    int fd = open (name, *mode);
    if (fd == -1) {
       	/* Error - errno already set */
       	return 0;
    }

    /* Remember fd, mark the file as opened */
    f->f_fd    = fd;
    f->f_flags = _FOPEN;

    /* Return the file descriptor */
    return f;
}



