/*
 * errno.h
 *
 * Ullrich von Bassewitz, 18.08.1998
 *
 */



#ifndef _ERRNO_H
#define _ERRNO_H



extern int _errno;		/* System error codes go here */
#define errno	_errno		/* ISO insists on a macro */



/* Possible error codes should go here */



#endif



