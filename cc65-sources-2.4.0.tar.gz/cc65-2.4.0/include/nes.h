/*
 * nes.h
 *
 * Ullrich von Bassewitz, 07.12.1998
 */



#ifndef _NES_H
#define _NES_H



/* Functions for accessing the ppu memory */
void __fastcall__ ReadPPU (unsigned addr);
void __fastcall__ WritePPU (unsigned char value, unsigned addr);
void __fastcall__ SetPPUaddress (unsigned address);
unsigned char ReadPPUseq (void);
void __fastcall__ WritePPUseq (unsigned char value);

/* Routines for palette manipulation */
void __fastcall__ SetBGpalette (unsigned char num, unsigned char val);
void __fastcall__ SetSPRpalette (unsigned char num, unsigned char val);
void __fastcall__ LoadBGpalette (unsigned char* palette);
void __fastcall__ LoadSPRpalette (unsigned char* palette);

/* Functions that handle the nes registers */
void __fastcall__ SetPPUctrl (unsigned char num, unsigned char value);
unsigned char ReadPPUstat (void);
void __fastcall__ WriteScroll (unsigned char vert, unsigned char horiz);



/* End of nes.h */

#endif



