/*****************************************************************************/
/*                                                                           */
/*				   pseudo.c				     */
/*                                                                           */
/*		Pseudo instructions for the ca65 macroassembler		     */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/* (C) 1998     Ullrich von Bassewitz                                        */
/*              Wacholderweg 14                                              */
/*              D-70597 Stuttgart                                            */
/* EMail:       uz@musoftware.de                                             */
/*                                                                           */
/*                                                                           */
/* This software is provided 'as-is', without any expressed or implied       */
/* warranty.  In no event will the authors be held liable for any damages    */
/* arising from the use of this software.                                    */
/*                                                                           */
/* Permission is granted to anyone to use this software for any purpose,     */
/* including commercial applications, and to alter it and redistribute it    */
/* freely, subject to the following restrictions:                            */
/*                                                                           */
/* 1. The origin of this software must not be misrepresented; you must not   */
/*    claim that you wrote the original software. If you use this software   */
/*    in a product, an acknowledgment in the product documentation would be  */
/*    appreciated but is not required.                                       */
/* 2. Altered source versions must be plainly marked as such, and must not   */
/*    be misrepresented as being the original software.                      */
/* 3. This notice may not be removed or altered from any source              */
/*    distribution.                                                          */
/*                                                                           */
/*****************************************************************************/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#include "../common/bitops.h"

#include "error.h"
#include "global.h"
#include "cputype.h"
#include "symtab.h"
#include "expr.h"
#include "key816.h"
#include "scanner.h"
#include "objcode.h"
#include "options.h"
#include "macro.h"
#include "macpack.h"
#include "pseudo.h"



/*****************************************************************************/
/*     	      	    	   	     Data				     */
/*****************************************************************************/



/* Are we inside a .IF condition that has been evaluated to TRUE? */
unsigned char IfCond = 1;

/* How many .IFs are currently open? */
unsigned OpenIfs = 0;

/* If condition stack */
#define MAX_IF_COUNT	16
static struct {
    unsigned char	Cond;		/* Condition */
    FilePos		Pos;		/* Position of starting command */
} IfStack [MAX_IF_COUNT];

/* Keyword we're about to handle */
static char Keyword [sizeof (SVal)];



/*****************************************************************************/
/*				 Forwards				     */
/*****************************************************************************/



static void DoUnexpected (void);



/*****************************************************************************/
/*	      	    	        Helper functions			     */
/*****************************************************************************/



static void ErrorSkip (unsigned ErrNum)
/* Print an error message and skip the rest of the line */
{
    Error (ErrNum);
    SkipUntilSep ();
}



static void SetBoolOption (unsigned char* Flag)
/* Read a +/- option and set flag accordingly */
{
    if (Tok == TOK_PLUS) {
       	*Flag = 1;
	NextTok ();
    } else if (Tok == TOK_MINUS) {
	*Flag = 0;
	NextTok ();
    } else if (Tok == TOK_SEP || Tok == TOK_EOF) {
	/* Without anything assume switch on */
	*Flag = 1;
    } else {
       	ErrorSkip (ERR_PLUSMINUS_EXPECTED);
    }
}



static void ExportImport (void (*SymFunc) (const char*, int), int ZP)
/* Export or import symbols */
{
    while (1) {
     	if (Tok != TOK_IDENT) {
       	    ErrorSkip (ERR_IDENT_EXPECTED);
     	    break;
     	}
     	SymFunc (SVal, ZP);
     	NextTok ();
     	if (Tok == TOK_COMMA) {
     	    NextTok ();
     	} else {
     	    break;
     	}
    }
}



static void SetIfCond (unsigned char Cond)
/* Start a new IF clause */
{
    if (OpenIfs >= MAX_IF_COUNT-1) {
	Error (ERR_IF_NESTING);
    } else {
	IfStack [OpenIfs].Cond = IfCond;	/* Remember old condition */
	IfStack [OpenIfs].Pos  = CurPos;	/* Remember file position */
	++OpenIfs;
       	IfCond = IfCond && Cond;
    }
}



/*****************************************************************************/
/*	      	    	       Handler functions			     */
/*****************************************************************************/



static void DoA16 (void)
/* Switch the accu to 16 bit mode (assembler only) */
{
    if (CPU != CPU_65816) {
	Error (ERR_816_MODE_ONLY);
    } else {
       	/* Immidiate mode has two extension bytes */
	ExtBytes [AMI_IMM_ACCU] = 2;
    }
}



static void DoA8 (void)
/* Switch the accu to 8 bit mode (assembler only) */
{
    if (CPU != CPU_65816) {
	Error (ERR_816_MODE_ONLY);
    } else {
	/* Immidiate mode has one extension byte */
	ExtBytes [AMI_IMM_ACCU] = 1;
    }
}



static void DoAddr (void)
/* Define addresses */
{
    while (1) {
	if (CPU == CPU_65816) {
       	    EmitWord (ForceWordExpr (Expression ()));
	} else {
	    /* Do a range check */
	    EmitWord (Expression ());
       	}
	if (Tok != TOK_COMMA) {
	    break;
	} else {
	    NextTok ();
	}
    }
}



static void DoAlign (void)
/* Align the PC to some boundary */
{
    long Val = ConstExpression ();
    if (Val <= 0 || Val > 0x10000) {
     	Error (ERR_RANGE);
    } else {
	unsigned Bit = BitFind (Val);
	if (Val != (0x01UL << Bit)) {
	    Error (ERR_ALIGN);
	} else {
	    SegAlign (Bit);
	}
    }
}



static void DoASCIIZ (void)
/* Define text with a zero terminator */
{
    while (1) {
    	if (Tok != TOK_STRCON) {
	    ErrorSkip (ERR_STRCON_EXPECTED);
	    return;
	}
	EmitData (SVal, strlen (SVal));
	NextTok ();
	if (Tok == TOK_COMMA) {
	    NextTok ();
	} else {
	    break;
	}
    }
    Emit0 (0);
}



static void DoAutoImport (void)
/* Mark unresolved symbols as imported */
{
    SetBoolOption (&AutoImport);
}



static void DoBss (void)
/* Switch to the BSS segment */
{
    UseBssSeg ();
}



static void DoByte (void)
/* Define bytes */
{
    while (1) {
	if (Tok == TOK_STRCON) {
	    /* A string */
	    EmitData (SVal, strlen (SVal));
	    NextTok ();
	} else {
	    EmitByte (Expression ());
	}
	if (Tok != TOK_COMMA) {
	    break;
	} else {
	    NextTok ();
	    /* Do smart handling of dangling comma */
	    if (Tok == TOK_SEP) {
		Error (ERR_UNEXPECTED_EOL);
	 	break;
	    }
	}
    }
}



static void DoCase (void)
/* Switch the IgnoreCase option */
{
    SetBoolOption (&IgnoreCase);
    IgnoreCase = !IgnoreCase;
}



static void DoCode (void)
/* Switch to the code segment */
{
    UseCodeSeg ();
}



static void DoData (void)
/* Switch to the data segment */
{
    UseDataSeg ();
}



static void DoDByt (void)
/* Output double bytes */
{
    while (1) {
	EmitWord (SwapExpr (Expression ()));
	if (Tok != TOK_COMMA) {
	    break;
	} else {
	    NextTok ();
	}
    }
}



static void DoDebugInfo (void)
/* Switch debug info on or off */
{
    SetBoolOption (&DbgSyms);
}



static void DoDWord (void)
/* Define dwords */
{
    while (1) {
       	EmitDWord (Expression ());
	if (Tok != TOK_COMMA) {
	    break;
	} else {
	    NextTok ();
	}
    }
}



static void DoElse (void)
/* Conditional assembly: .ELSE */
{
    if (OpenIfs == 0) {
	DoUnexpected ();
    } else {
	unsigned I;
	unsigned char OldCond = 1;
	for (I = 0; I < OpenIfs; ++I) {
	    OldCond = OldCond && IfStack [I].Cond;
	}
	if (OldCond) {
	    IfCond = !IfCond;
	}
    }
}



static void DoElseIf (void)
/* Conditional assembly: .ELSEIF */
{
    if (OpenIfs == 0) {
	DoUnexpected ();
    } else {
	long Val;
	unsigned I;
	unsigned char OldCond = 1;
	for (I = 0; I < OpenIfs; ++I) {
	    OldCond = OldCond && IfStack [I].Cond;
	}
	Val = ConstExpression ();
	if (OldCond && !IfCond) {
       	    IfCond = Val != 0;
	    /* Remember the new position */
	    IfStack [OpenIfs-1].Pos = CurPos;
	}
    }
}



static void DoEnd (void)
/* End of assembly */
{
    ForcedEnd = 1;
}



static void DoEndIf (void)
/* Conditional assembly: .ENDIF */
{
    if (OpenIfs == 0) {
    	DoUnexpected ();
    } else {
    	IfCond = IfStack [--OpenIfs].Cond;
    }
}



static void DoEndProc (void)
/* Leave a lexical level */
{
    SymLeaveLevel ();
}



static void DoError (void)
/* Use error */
{
    if (Tok != TOK_STRCON) {
 	ErrorSkip (ERR_STRCON_EXPECTED);
    } else {
       	Error (ERR_USER, SVal);
	SkipUntilSep ();
    }
}



static void DoExitMacro (void)
/* Exit a macro expansion */
{
    if (!InMacExpansion ()) {
	/* We aren't expanding a macro currently */
       	DoUnexpected ();
    } else {
	MacAbort ();
    }
}



static void DoExport (void)
/* Export a symbol */
{
    ExportImport (SymExport, 0);
}



static void DoExportZP (void)
/* Export a zeropage symbol */
{
    ExportImport (SymExport, 1);
}



static void DoFarAddr (void)
/* Define far addresses (24 bit) */
{
    while (1) {
       	EmitFarAddr (Expression ());
	if (Tok != TOK_COMMA) {
	    break;
	} else {
	    NextTok ();
	}
    }
}



static void DoFileOpt (void)
/* Insert a file option */
{
    long OptNum;

    /* The option type may be given as a keyword or as a number. */
    if (Tok == TOK_IDENT) {

	/* Option given as keyword */
	static const char* Keys [] = {
	    "AUTHOR", "COMMENT", "COMPILER"
      	};

	/* Map the option to a number */
	OptNum = GetSubKey (Keys, sizeof (Keys) / sizeof (Keys [0]));
	if (OptNum < 0) {
	    /* Not found */
	    ErrorSkip (ERR_OPTION_KEY_EXPECTED);
	    return;
	}

	/* Skip the keyword */
	NextTok ();

	/* Must be followed by a comma */
	Consume (TOK_COMMA, ERR_COMMA_EXPECTED);

	/* We accept only string options for now */
	if (Tok != TOK_STRCON) {
	    ErrorSkip (ERR_STRCON_EXPECTED);
	    return;
	}

       	/* Insert the option */
	switch (OptNum) {

	    case 0:
		/* Author */
		OptAuthor (SVal);
		break;

	    case 1:
		/* Comment */
		OptComment (SVal);
		break;

	    case 2:
		/* Compiler */
		OptCompiler (SVal);
		break;

	    default:
	        Internal ("Invalid OptNum: %l", OptNum);

	}

	/* Done */
	NextTok ();

    } else {

     	/* Option given as number */
       	OptNum = ConstExpression ();
     	if (!IsByteRange (OptNum)) {
     	    ErrorSkip (ERR_RANGE);
     	    return;
     	}

	/* Must be followed by a comma */
	Consume (TOK_COMMA, ERR_COMMA_EXPECTED);

	/* We accept only string options for now */
	if (Tok != TOK_STRCON) {
	    ErrorSkip (ERR_STRCON_EXPECTED);
	    return;
	}

	/* Insert the option */
	OptStr ((unsigned char) OptNum, SVal);

	/* Done */
	NextTok ();
    }
}



static void DoGlobal (void)
/* Declare a global symbol */
{
    ExportImport (SymGlobal, 0);
}



static void DoGlobalZP (void)
/* Declare a global zeropage symbol */
{
    ExportImport (SymGlobal, 1);
}



static void DoI16 (void)
/* Switch the index registers to 16 bit mode (assembler only) */
{
    if (CPU != CPU_65816) {
     	Error (ERR_816_MODE_ONLY);
    } else {
       	/* Immidiate mode has two extension bytes */
     	ExtBytes [AMI_IMM_INDEX] = 2;
    }
}



static void DoI8 (void)
/* Switch the index registers to 16 bit mode (assembler only) */
{
    if (CPU != CPU_65816) {
	Error (ERR_816_MODE_ONLY);
    } else {
	/* Immidiate mode has one extension byte */
	ExtBytes [AMI_IMM_INDEX] = 1;
    }
}



static void DoIf (void)
/* Conditional assembly: .IF */
{
    if (IfCond) {
        SetIfCond (ConstExpression () != 0);
    } else {
	/* No errors if the expression is not const */
	ExprNode* Expr = Expression ();
	if (IsConstExpr (Expr)) {
	    SetIfCond (GetExprVal (Expr) != 0);
	} else {
	    SetIfCond (0);
	}
	FreeExpr (Expr);
    }
}



static void DoIfBlank (void)
/* Conditional assembly: .IFBLANK */
{
    SetIfCond (Tok == TOK_SEP);
    SkipUntilSep ();
}



static void DoIfConst (void)
/* Conditional assembly: .IFCONST */
{
    /* Read an expression */
    ExprNode* Expr = Expression ();

    /* Condition is true if the expression is const */
    SetIfCond (IsConstExpr (Expr));

    /* Free the expression */
    FreeExpr (Expr);
}



static void DoIfDef (void)
/* Conditional assembly: .IFDEF */
{
    if (Tok != TOK_IDENT) {
	ErrorSkip (ERR_IDENT_EXPECTED);
    } else {
	SetIfCond (SymIsDef (SVal));
	NextTok ();
    }
}



static void DoIfNBlank (void)
/* Conditional assembly: .IFNBLANK */
{
    SetIfCond (Tok != TOK_SEP);
    SkipUntilSep ();
}



static void DoIfNConst (void)
/* Conditional assembly: .IFNCONST */
{
    /* Read an expression */
    ExprNode* Expr = Expression ();

    /* Condition is true if the expression is not const */
    SetIfCond (!IsConstExpr (Expr));

    /* Free the expression */
    FreeExpr (Expr);
}



static void DoIfNDef (void)
/* Conditional assembly: .IFNDEF */
{
    if (Tok != TOK_IDENT) {
	ErrorSkip (ERR_IDENT_EXPECTED);
    } else {
	SetIfCond (!SymIsDef (SVal));
	NextTok ();
    }
}



static void DoIfNRef (void)
/* Conditional assembly: .IFNREF */
{
    if (Tok != TOK_IDENT) {
	ErrorSkip (ERR_IDENT_EXPECTED);
    } else {
	SetIfCond (!SymIsRef (SVal));
	NextTok ();
    }
}



static void DoIfP02 (void)
/* Conditional assembly: .IFP02 */
{
    SetIfCond (CPU == CPU_6502);
}



static void DoIfP816 (void)
/* Conditional assembly: .IFP816 */
{
    SetIfCond (CPU == CPU_65816);
}



static void DoIfPC02 (void)
/* Conditional assembly: .IFPC02 */
{
    SetIfCond (CPU == CPU_65C02);
}



static void DoIfRef (void)
/* Conditional assembly: .IFREF */
{
    if (Tok != TOK_IDENT) {
	ErrorSkip (ERR_IDENT_EXPECTED);
    } else {
	SetIfCond (SymIsRef (SVal));
	NextTok ();
    }
}



static void DoImport (void)
/* Import a symbol */
{
    ExportImport (SymImport, 0);
}



static void DoImportZP (void)
/* Import a zero page symbol */
{
    ExportImport (SymImport, 1);
}



static void DoIncBin (void)
/* Include a binary file */
{
    /* Name must follow */
    if (Tok != TOK_STRCON) {
	ErrorSkip (ERR_STRCON_EXPECTED);
    } else {
	/* Try to open the file */
	FILE* F = fopen (SVal, "rb");
	if (F == 0) {
	    Error (ERR_CANNOT_OPEN_INCLUDE, SVal, strerror (errno));
	} else {
 	    unsigned char Buf [1024];
	    size_t Count;
	    /* Read chunks and insert them into the output */
	    while ((Count = fread (Buf, 1, sizeof (Buf), F)) > 0) {
		EmitData (Buf, Count);
	    }
	    /* Close the file, ignore errors since it's r/o */
	    (void) fclose (F);
	}
	/* Skip the name */
	NextTok ();
    }
}



static void DoInclude (void)
/* Include another file */
{
    char Name [MAX_STR_LEN+1];

    /* Name must follow */
    if (Tok != TOK_STRCON) {
	ErrorSkip (ERR_STRCON_EXPECTED);
    } else {
	strcpy (Name, SVal);
	NextTok ();
	NewInputFile (Name);
    }
}



static void DoLocalChar (void)
/* Define the character that starts local labels */
{
    if (Tok != TOK_CHARCON) {
     	ErrorSkip (ERR_CHARCON_EXPECTED);
    } else {
	if (IVal != '@' && IVal != '?') {
	    Error (ERR_ILLEGAL_LOCALSTART);
	} else {
     	    LocalStart = IVal;
       	}
     	NextTok ();
    }
}



static void DoMacPack (void)
/* Insert a macro package */
{
    /* Macro package names */
    static const char* Keys [] = {
	"GENERIC",
       	"LONGBRANCH",
    };

    int Package;

    /* We expect an identifier */
    if (Tok != TOK_IDENT) {
    	ErrorSkip (ERR_IDENT_EXPECTED);
    	return;
    }

    /* Map the keyword to a number */
    Package = GetSubKey (Keys, sizeof (Keys) / sizeof (Keys [0]));
    if (Package < 0) {
    	/* Not found */
    	ErrorSkip (ERR_ILLEGAL_MACPACK);
    	return;
    }

    /* Skip the package name */
    NextTok ();

    /* Insert the package */
    InsertMacPack (Package);
}



static void DoMacro (void)
/* Start a macro definition */
{
    MacDef ();
}



static void DoOrg (void)
/* Start absolute code */
{
    long PC = ConstExpression ();
    if (PC < 0 || PC > 0xFFFF) {
	Error (ERR_RANGE);
    	return;
    }
    SetAbsPC (PC);
}



static void DoOut (void)
/* Output a string */
{
    if (Tok != TOK_STRCON) {
	ErrorSkip (ERR_STRCON_EXPECTED);
    } else {
	printf ("%s\n", SVal);
	NextTok ();
    }
}



static void DoP02 (void)
/* Switch to 6502 CPU */
{
    CPU = CPU_6502;
}



static void DoPC02 (void)
/* Switch to 65C02 CPU */
{
    CPU = CPU_65C02;
}



static void DoP816 (void)
/* Switch to 65816 CPU */
{
    CPU = CPU_65816;
}



static void DoProc (void)
/* Start a new lexical scope */
{
    if (Tok == TOK_IDENT) {
	/* The new scope has a name */
	SymDef (SVal, CurrentPC (), IsZPSeg ());
	NextTok ();
    }
    SymEnterLevel ();
}



static void DoReloc (void)
/* Enter relocatable mode */
{
    RelocMode = 1;
}



static void DoRes (void)
/* Reserve some number of storage bytes */
{
    long Count;
    long Val;

    Count = ConstExpression ();
    if (Count > 0xFFFF || Count < 0) {
	ErrorSkip (ERR_RANGE);
	return;
    }
    if (Tok == TOK_COMMA) {
	NextTok ();
	Val = ConstExpression ();
	/* We need a byte value here */
	if (!IsByteRange (Val)) {
       	    ErrorSkip (ERR_RANGE);
	    return;
	}
    } else {
	Val = 0;
    }

    /* Emit constant values */
    while (Count--) {
	Emit0 ((unsigned char) Val);
    }
}



static void DoROData (void)
/* Switch to the r/o data segment */
{
    UseRODataSeg ();
}



static void DoSegment (void)
/* Switch to another segment */
{
    static const char* AttrTab [] = {
	"ZEROPAGE", "DIRECT",
	"ABSOLUTE",
	"FAR", "LONG"
    };
    char Name [sizeof (SVal)];
    int SegType;

    if (Tok != TOK_STRCON) {
	ErrorSkip (ERR_STRCON_EXPECTED);
    } else {

	/* Save the name of the segment and skip it */
	strcpy (Name, SVal);
	NextTok ();

	/* Check for an optional segment attribute */
	SegType = SEGTYPE_DEFAULT;
	if (Tok == TOK_COMMA) {
	    NextTok ();
	    if (Tok != TOK_IDENT) {
	     	ErrorSkip (ERR_IDENT_EXPECTED);
	    } else {
		int Attr = GetSubKey (AttrTab, sizeof (AttrTab) / sizeof (AttrTab [0]));
		switch (Attr) {

		    case 0:
		    case 1:
			/* Zeropage */
		    	SegType = SEGTYPE_ZP;
			break;

		    case 2:
			/* Absolute */
		    	SegType = SEGTYPE_ABS;
			break;

		    case 3:
		    case 4:
			/* Far */
		    	SegType = SEGTYPE_FAR;
			break;

		    default:
	     	        Error (ERR_ILLEGAL_SEG_ATTR);
	     	}
		NextTok ();
	    }
	}

	/* Set the segment */
     	UseSeg (Name, SegType);
    }
}



static void DoSmart (void)
/* Smart mode on/off */
{
    SetBoolOption (&SmartMode);
}



static void DoUnexpected (void)
/* Got an unexpected keyword */
{
    Error (ERR_UNEXPECTED_KEYWORD, Keyword);
    SkipUntilSep ();
}



static void DoWord (void)
/* Define words */
{
    while (1) {
       	EmitWord (Expression ());
	if (Tok != TOK_COMMA) {
	    break;
	} else {
	    NextTok ();
	}
    }
}



static void DoZeropage (void)
/* Switch to the zeropage segment */
{
    UseZeropageSeg ();
}



/*****************************************************************************/
/*	      		   	  Table data				     */
/*****************************************************************************/



/* Control command table */
struct CtrlDesc_ {
    int	      	    ForceIf;		/* Exec inside a FALSE .IFDEF */
    void       	    (*Handler) (void);	/* Command handler */
};
typedef struct CtrlDesc_ CtrlDesc;

#define PSEUDO_COUNT 	(sizeof (CtrlCmdTab) / sizeof (CtrlCmdTab [0]))
static CtrlDesc CtrlCmdTab [] = {
    { 0,       	DoA16		},
    { 0,       	DoA8		},
    { 0,        DoAddr 	       	},     	/* .ADDR */
    { 0,       	DoAlign		},
    { 0,       	DoASCIIZ	},
    { 0,       	DoAutoImport	},
    { 0,        DoUnexpected	},	/* .BLANK */
    { 0,       	DoBss		},
    { 0,       	DoByte		},
    { 0,       	DoCase		},
    { 0,	DoCode		},
    { 0,	DoUnexpected	},	/* .CONST */
    { 0,	DoData		},
    { 0,	DoDByt		},
    { 0,        DoDebugInfo	},
    { 0,	DoUnexpected	},	/* .DEFINED */
    { 0,	DoDWord		},
    { 1,	DoElse	  	},
    { 1,	DoElseIf  	},
    { 0,	DoEnd	  	},
    { 1,	DoEndIf	  	},
    { 0,     	DoUnexpected	},	/* .ENDMACRO */
    { 0,	DoEndProc	},
    { 0,	DoError	  	},
    { 0,	DoExitMacro	},
    { 0,	DoExport  	},
    { 0,       	DoExportZP	},
    { 0,        DoFarAddr	},
    { 0,	DoFileOpt	},
    { 0,	DoGlobal	},
    { 0,	DoGlobalZP	},
    { 0,	DoI16	  	},
    { 0,	DoI8	  	},
    { 1,	DoIf	  	},
    { 1,	DoIfBlank	},
    { 1,	DoIfConst	},
    { 1,	DoIfDef	  	},
    { 1,     	DoIfNBlank	},
    { 1,	DoIfNConst	},
    { 1,	DoIfNDef  	},
    { 1,	DoIfNRef  	},
    { 1,	DoIfP02	  	},
    { 1,	DoIfP816    	},
    { 1,	DoIfPC02  	},
    { 1,	DoIfRef	  	},
    { 0,	DoImport  	},
    { 0,	DoImportZP	},
    { 0,	DoIncBin	},
    { 0,      	DoInclude	},
    { 0,	DoUnexpected	},	/* .LOCAL */
    { 0,	DoLocalChar	},
    { 0,	DoMacPack	},
    { 0,	DoMacro		},
    { 0,	DoOrg		},
    { 0,	DoOut		},
    { 0,	DoP02		},
    { 0,	DoP816		},
    { 0,       	DoUnexpected   	},	/* .PARAMCOUNT */
    { 0,	DoPC02		},
    { 0,	DoProc		},
    { 0,	DoUnexpected   	},	/* .REFERENCED */
    { 0,	DoReloc		},
    { 0,	DoRes		},
    { 0,	DoROData	},
    { 0,       	DoSegment	},
    { 0,        DoSmart		},
    { 0,       	DoWord		},
    { 0,       	DoZeropage	},
};



/*****************************************************************************/
/*     	       	    		     Code				     */
/*****************************************************************************/



int TokIsPseudo (unsigned Tok)
/* Return true if the given token is a pseudo instruction token */
{
    return (Tok >= TOK_FIRSTPSEUDO && Tok <= TOK_LASTPSEUDO);
}



void HandlePseudo (void)
/* Handle a pseudo instruction */
{
    CtrlDesc* D;

    /* Calculate the index into the table */
    unsigned Index = Tok - TOK_FIRSTPSEUDO;

    /* Safety check */
    if (PSEUDO_COUNT != (TOK_LASTPSEUDO - TOK_FIRSTPSEUDO + 1)) {
	Internal ("Pseudo mismatch: PSEUDO_COUNT = %u, actual count = %u\n",
		  PSEUDO_COUNT, TOK_LASTPSEUDO - TOK_FIRSTPSEUDO + 1);
    }
    CHECK (Index < PSEUDO_COUNT);

    /* Remember the instruction, then skip it */
    strcpy (Keyword, SVal);
    NextTok ();

    /* Call the handler */
    D = &CtrlCmdTab [Index];
    if (IfCond || D->ForceIf) {
     	D->Handler ();
    } else {
     	SkipUntilSep ();
    }
}



void CheckOpenIfs (void)
/* Called at end of translation, checks if any .IF branches are open */
{
    if (OpenIfs) {
	PError (&IfStack [OpenIfs-1].Pos, ERR_OPEN_IF);
    }
}



