/*****************************************************************************/
/*                                                                           */
/*				   key816.h				     */
/*                                                                           */
/*	       Instruction encoding for the ca65 macroassembler		     */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/* (C) 1998     Ullrich von Bassewitz                                        */
/*              Wacholderweg 14                                              */
/*              D-70597 Stuttgart                                            */
/* EMail:       uz@musoftware.de                                             */
/*                                                                           */
/*                                                                           */
/* This software is provided 'as-is', without any expressed or implied       */
/* warranty.  In no event will the authors be held liable for any damages    */
/* arising from the use of this software.                                    */
/*                                                                           */
/* Permission is granted to anyone to use this software for any purpose,     */
/* including commercial applications, and to alter it and redistribute it    */
/* freely, subject to the following restrictions:                            */
/*                                                                           */
/* 1. The origin of this software must not be misrepresented; you must not   */
/*    claim that you wrote the original software. If you use this software   */
/*    in a product, an acknowledgment in the product documentation would be  */
/*    appreciated but is not required.                                       */
/* 2. Altered source versions must be plainly marked as such, and must not   */
/*    be misrepresented as being the original software.                      */
/* 3. This notice may not be removed or altered from any source              */
/*    distribution.                                                          */
/*                                                                           */
/*****************************************************************************/



#ifndef OPCTABLE_H
#define OPCTABLE_H



#include "cputype.h"



/*****************************************************************************/
/*     	     	    		     Data   				     */
/*****************************************************************************/



/* Constants for the addressing mode. If an opcode is available in zero page
 * and absolut adressing mode, both bits are set. When checking for valid
 * modes, the zeropage bit is checked first. Similar, the implicit bit is set
 * on accu adressing modes, so the 'A' for accu adressing is not needed (but
 * may be specified).
 * When assembling for the 6502 or 65C02, all addressing modes that are not
 * available on these CPUs are removed before doing any checks.
 */
#define AM_IMPLICIT    	       	0x00000003L
#define AM_ACCU	       	       	0x00000002L
#define AM_DIR      	       	0x00000004L
#define AM_ABS     	       	0x00000008L
#define AM_ABS_LONG  		0x00000010L
#define AM_DIR_X 	  	0x00000020L
#define AM_ABS_X            	0x00000040L
#define AM_ABS_LONG_X		0x00000080L
#define AM_DIR_Y               	0x00000100L
#define AM_ABS_Y           	0x00000200L
#define AM_DIR_IND      	0x00000400L
#define AM_ABS_IND     		0x00000800L
#define AM_DIR_IND_LONG     	0x00001000L
#define AM_DIR_IND_Y     	0x00002000L
#define AM_DIR_IND_LONG_Y    	0x00004000L
#define AM_DIR_X_IND         	0x00008000L
#define AM_ABS_X_IND    	0x00010000L
#define AM_REL             	0x00020000L
#define AM_REL_LONG            	0x00040000L
#define AM_STACK_REL        	0x00080000L
#define AM_STACK_REL_IND_Y	0x00100000L
#define AM_IMM           	0x00E00000L
#define AM_BLOCKMOVE           	0x01000000L

/* Bitmask for all ZP operations that have correspondent ABS ops */
#define AM_ZP	(AM_DIR | AM_DIR_X | AM_DIR_Y | AM_DIR_IND | AM_DIR_X_IND)

/* Bit numbers and count */
#define AMI_IMM_ACCU		21
#define AMI_IMM_INDEX		22
#define AMI_COUNT		25

/* Number of instructions */
#define INSTR_COUNT		101



/* Description for one instruction */
struct InstrDesc_ {
    char		Mnemonic [4];
    unsigned long	AddrMode [CPU_COUNT];	/* Valid adressing modes */
    unsigned char	BaseCode;  	 	/* Base opcode */
    unsigned char	ExtCode;   	 	/* Number of ext code table */
    void       	       	(*Emit) (const struct InstrDesc_*);/* Handler function */
};
typedef struct InstrDesc_ InstrDesc;

/* Instruction table */
extern InstrDesc InstrTab [INSTR_COUNT];

/* Table to build the effective opcode from a base opcode and an addressing
 * mode.
 */
extern unsigned char EATab [8][AMI_COUNT];

/* Table that encodes the additional bytes for each instruction */
extern unsigned char ExtBytes [AMI_COUNT];



/*****************************************************************************/
/*     	     	    		     Code   				     */
/*****************************************************************************/



int FindInstruction (const char* Ident);
/* Check if Ident is a valid mnemonic. If so, return the index in the
 * instruction table. If not, return -1.
 */

void HandleInstruction (unsigned Index);
/* Handle the mnemonic with the given index */



/* End of key816.h */

#endif



