/*
 * datatype.c
 *
 * Ullrich von Bassewitz, 02.10.1998
 */



#include <string.h>

#include "mem.h"
#include "symtab.h"
#include "datatype.h"



/*****************************************************************************/
/*				     Data				     */
/*****************************************************************************/



/* Predefined type strings */
type type_int []	= { T_INT,	T_END };
type type_uint []	= { T_UINT,	T_END };
type type_long []	= { T_LONG,	T_END };
type type_ulong []	= { T_ULONG,	T_END };
type type_empty []	= { T_EMPTY,	T_END };
type type_void []	= { T_VOID,	T_END };
type type_ellipsis []	= { T_ELLIPSIS, T_END };
type type_ifunc []	= { T_FUNC,  0, 0, 0, T_INT,  T_END };
type type_carray []	= { T_ARRAY, 0, 0, 0, T_UCHAR, T_END };
type type_pchar []      = { T_PTR, T_UCHAR, T_END };



/*****************************************************************************/
/*				     Code				     */
/*****************************************************************************/



unsigned TypeLen (const type* T)
/* Return the length of the type string */
{
    const type* Start = T;
    while (*T) {
	++T;
    }
    return T - Start;
}



int TypeCmp (const type* T1, const type* T2)
/* Compare two type strings */
{
    int A, B, D;
    do {
	A = *T1++;
	B = *T2++;
	D = A - B;
    } while (D == 0 && A != 0);
    return D;
}



type* TypeCpy (type* Dest, const type* Src)
/* Copy a type string */
{
    type T;
    type* Orig = Dest;
    do {
	T = *Src++;
	*Dest++ = T;
    } while (T);
    return Orig;
}



type* TypeCat (type* Dest, const type* Src)
/* Append Src */
{
    TypeCpy (Dest + TypeLen (Dest), Src);
    return Dest;
}



type* TypeDup (const type* T)
/* Create a copy of the given type on the heap */
{
    unsigned Len = (TypeLen (T) + 1) * sizeof (type);
    return memcpy (xmalloc (Len), T, Len);
}



type* TypeAlloc (unsigned Len)
/* Allocate memory for a type string of length Len. Len *must* include the
 * trailing T_END.
 */
{
    return xmalloc (Len * sizeof (type));
}



void TypeFree (type* T)
/* Free a type string */
{
    xfree (T);
}



