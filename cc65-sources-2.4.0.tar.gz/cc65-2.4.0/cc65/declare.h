/*
 * declare.h
 *
 * Ullrich von Bassewitz, 20.06.1998
 */



#ifndef DECLARE_H
#define DECLARE_H



#include "symtab.h"



/*****************************************************************************/
/*		      		     code				     */
/*****************************************************************************/



int istypedef (struct hashent* psym);
/* Return true if psym is a typedef */

int gettypedef (struct hashent** psym, type* tarray);
/* Check if the following tokens are a typedef. If so, process it and return
 * true. If not, return false. The symbol and the type are returned as psym
 * and tarray.
 */

unsigned getsclass (int level, unsigned dflt);
/* Process "<storage-class>" */

void ptype (struct hashent *psym, type* tarray);
/* Output translation of type array. */

type gettype (int dflt, struct hashent** sptr);
/* gettype( dflt ) Process "<type>" */

struct hashent* declare (type* ptyp, type t, struct hashent *sadr, int mode);
/* Construct a type array. */

void parseinit (type* tptr);
/* Parse initialization of variables */



/* End of declare.h */

#endif



