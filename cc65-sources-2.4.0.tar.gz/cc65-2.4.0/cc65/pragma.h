/*
 * pragma.h
 *
 * Ullrich von Bassewitz, 11.08.1998
 */



#ifndef PRAGMA_H
#define PRAGMA_H



/*****************************************************************************/
/*		     		     code				     */
/*****************************************************************************/



void DoPragma (void);
/* Handle pragmas */



/* End of pragma.h */
#endif





