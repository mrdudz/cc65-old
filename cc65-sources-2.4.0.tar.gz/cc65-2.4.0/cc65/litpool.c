/*
 * litpool.c
 *
 * Ullrich von Bassewitz, 06.08.1998
 */



#include "global.h"
#include "util.h"
#include "ctrans.h"
#include "codegen.h"
#include "litpool.h"



/*****************************************************************************/
/*		    		     data				     */
/*****************************************************************************/



unsigned char litpool [LITPOOL_SIZE];	/* The literal pool */
unsigned litptr	   	= 0;		/* Current pool offset */
unsigned litlabel  	= 1;		/* Pool asm label */
unsigned litspace  	= 0;		/* Space used (stats only) */



/*****************************************************************************/
/*		    		     code				     */
/*****************************************************************************/



void littrans (unsigned offs)
/* Translate the literals starting from the given offset into the target
 * charset.
 */
{
    while (offs < litptr) {
     	litpool [offs] = ctrans (litpool [offs]);
	++offs;
    }
}



void dumplits (void)
/* Dump the literal pool */
{
    /* if nothing there, exit... */
    if (litptr == 0) {
	return;
    }

    /* Switch to the data segment */
    if (WriteableStrings) {
     	g_usedata ();
    } else {
       	g_userodata ();
    }

    /* Define the label */
    g_defloclabel (litlabel);

    /* Translate the buffer contents into the target charset */
    littrans (0);

    /* Output the buffer data */
    g_defbytes (litpool, litptr);

    /* Switch back to the code segment */
    g_usecode ();

    /* Reset the buffer */
    litspace += litptr;	  	/* account for space */
    litlabel  = getlabel (); 	/* get next lit pool label */
    litptr    = 0;
}



