/*
 * pet.h
 *
 * Ullrich von Bassewitz, 26.11.1998
 */



#ifndef _PET_H
#define _PET_H



/* Color defines */
#define COLOR_BLACK  	       	0x00
#define COLOR_WHITE  	       	0x01



/* End of pet.h */
#endif



