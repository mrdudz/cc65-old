/*
 * mem.h
 *
 * Ullrich von Bassewitz, 07.06.1998
 */



#ifndef MEM_H
#define MEM_H



#include <stddef.h>



/*****************************************************************************/
/*  	     	  		     data				     */
/*****************************************************************************/



extern size_t memmax;



/*****************************************************************************/
/*     	     	    		     code				     */
/*****************************************************************************/



void* xmalloc (size_t size);
/* Allocate memory, check for out of memory condition. Do some debugging */

void xfree (const void* block);
/* Free the block, do some debugging */

char* xstrdup (const char* s);
/* Duplicate a string on the heap. The function checks for out of memory */



/* End of mem.h */
#endif



