/*
 * strerror.c
 *
 * Ullrich von Bassewitz, 11.06.1998
 */



#include <stdio.h>



char* strerror (int errcode)
{
    /* Do it the easy way until we get real error codes */
    static char buf [15];
    sprintf (buf, "error #%d", errcode);
    return buf;
}



